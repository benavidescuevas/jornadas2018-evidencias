Carlos Manuel Cabello Colmenares, grupo 2.
Comit� de Programa

Paquete: Contacto y Comunicaciones con Ponente

Se han incluido en este paquete todas las evidencias relacionadas con las comunicaciones con
el ponente Diego Fernandez Barrera, que finalmente culminaron en la ponencia 
"Blockchain: Qu� es y como funciona". Tambi�n incluye la recepci�n del ponente.

*Evidencia 7

En este paquete se contabilizan 3'1h en total.



