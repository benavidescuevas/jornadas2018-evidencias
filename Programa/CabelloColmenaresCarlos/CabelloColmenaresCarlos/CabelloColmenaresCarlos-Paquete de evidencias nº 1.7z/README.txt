Carlos Manuel Cabello Colmenares, grupo 2.
Comit� de Programa

Paquete: Reuniones y Colaboraci�n como secretario

Se han incluido en este paquete todas las evidencias relacionadas con las reuniones a las que
asist�, as� como las respectivas actas que me encargu� de realizar.

*Evidencia 1: Reuni�n 10 de octubre 2018 + Acta => fueron 2'25h
*Evidencia 2: Reuni�n 17 de octubre 2018 + Acta => fueron 2'25h
*Evidencia 3: Reuni�n 24 de octubre 2018 + Acta => fueron 1'25h
*Evidencia 4: Reuni�n 31 de octubre de 2018 + Acta => fueron 1'25h

En este paquete se contabilizan 7h en total.



