Carlos Manuel Cabello Colmenares, grupo 2.
Comit� de Programa

Paquete: Organizaci�n de Exposici�n de Ordenadores y SSOO Antiguos

Se han incluido en este paquete todas las evidencias relacionadas con la colaboraci�n en la 
exposici�n de ordenadores y SSOO antiguos.

*Evidencia 5: B�squeda de SSOO relevantes hist�ricamente y la forma de emularlos => fueron 4h

*Evidencia 6: Elaboraci�n de fichas informativas para la exposici�n, colaboraci�n con el montaje
y devoluci�n de los ordenadores al centro de c�lculo => fueron 4'5h

En este paquete se contabilizan 9'5h en total.



