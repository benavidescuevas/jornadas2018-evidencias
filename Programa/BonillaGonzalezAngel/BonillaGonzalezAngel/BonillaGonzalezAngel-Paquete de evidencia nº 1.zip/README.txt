En este paquete he incluído una reunión del comité de programa (2 horas), la elaboración de un programa en Scratch para el taller de niños (3 horas) y la elaboración de la guía a usar durante las sesiones del taller (3 horas y 40 minutos).

Total de horas:8 horas y 40 minutos.

NOTA: los archivos que sirven para justificar las evidencias están incluídos en la propia evidencia, en la segunda página de esta (también existen enlaces para descargar los archivos).
