En este paquete se ha incluído la elaboración del enunciado para TOURNAMETSII (40 minutos), la evidencia con respecto a mi presencia en TOURNAMETSII como organizador (3 horas y 30 minutos) y la evidencia con respecto a mi presencia como organizador en las dos sesiones del taller de niños (4 horas y 30 minutos).

Total de horas: 14 horas y 40 minutos (las horas de TOURNAMETSII y el taller de niños cuentan como doble).

NOTA: los archivos que sirven para justificar las evidencias están incluídos en la propia evidencia, en la segunda página de esta (también existen enlaces para descargar los archivos).
