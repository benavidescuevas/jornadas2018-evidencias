En este paquete, va incluido tres evidencias:
· Dos reuniones realizadas con el comité de programa: 2 horas y media.
· Microtrabajo - Buzón web: Media hora.
· Asistencia: 7 horas
· Asistencia a la mesa redonda: 1 hora y 40 minutos.

En total, en este paquete hay un total de 11 horas y 40 minutos trabajadas.