He decidido en estas evidencias centrarme m�s en la tarea 
de investigaci�n y propuestas para el taller de los ni�os.

Horas totales en estas evidencias: 3 horas y 40 minutos