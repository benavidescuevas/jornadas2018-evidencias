N�mero total de horas: 12 horas 55 minutos

Este paquete tiene 5 evidencias. Son las siguientes:
- Evidencia sobre la preparaci�n, el mantenimiento y el cierre de la exposici�n.
- Dos evidencias sobre dos reuniones de Programa.
- Dos evidencias sobre dos reuniones de Coordinaci�n.

Para facilitar la organizaci�n de documentos anexos, he creado 5 carpetas para las diferentes evidencias.