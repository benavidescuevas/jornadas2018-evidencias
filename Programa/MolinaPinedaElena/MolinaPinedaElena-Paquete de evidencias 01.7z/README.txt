Explicacion de las evidencias:

Mi labor principal ha sido crear la scaperoom junto a mi compa�ero Carlos, desde pensar en las pruebas y todo el desarrollo y cadena
de pistas hasta crearlas, dise�arlas y materializarlas, adem�s del contexto, decoraci�n y asistencia a la actividad, siendo
gu�a de los participantes.

Total de horas invertidas en las jornadas: 42,8 h