Este paquete contiene las evidencias correspondientes a las reuniones realizadas en el comité de programa.
Horas totales: 3
