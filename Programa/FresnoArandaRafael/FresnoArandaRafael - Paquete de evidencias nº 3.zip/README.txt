Este paquete contiene las evidencias correspondientes a la preparación y el desarrollo de la charla "OAS-Tools/Generator: construcción automatizada de APIs RESTful con gestión de la seguridad".
Horas totales: 9.3
