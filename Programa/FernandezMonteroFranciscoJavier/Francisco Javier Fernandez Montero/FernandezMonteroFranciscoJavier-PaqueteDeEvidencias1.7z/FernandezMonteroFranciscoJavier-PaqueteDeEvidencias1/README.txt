Horas: 23
Se incluyen 3 evidencias relacionadas con el museo interactivo de las jornadas.
- Montar el museo y pedir ordenadores al centro de calculo 
- Obtenci�n de c�digo fuente relevante para la ingenier�a del software.
- Encargado del museo el d�a de la exposici�n.

