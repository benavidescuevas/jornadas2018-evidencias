En este paquete se presentan las evidencias de las reuniones para la organizaci�n del museo.
Horas totales: 3:15 horas.