En este paquete se presentan las evidencias de la preparaci�n de los ordenadores, de la exposici�n y su posterior vigilancia durante las jornadas.
Horas totales: 11:30 horas.