En este paquete se presentan las evidencias de las reuniones en el comit� de Programa y las propuestas para la primera reuni�n.
Horas totales: 4:05 horas.