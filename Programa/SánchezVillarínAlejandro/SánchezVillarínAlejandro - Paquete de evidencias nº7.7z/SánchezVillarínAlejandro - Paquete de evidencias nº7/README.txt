En este paquete se presentan las evidencias de las asistencias a las conferencias, talleres o mesas redondas durante las jornadas.
Horas totales: 7:00 horas. (9:30 horas sin limitaci�n)