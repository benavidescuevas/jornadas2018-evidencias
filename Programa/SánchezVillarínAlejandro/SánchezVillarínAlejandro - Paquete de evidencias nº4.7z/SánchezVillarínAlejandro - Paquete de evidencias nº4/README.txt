En este paquete se presentan las evidencias de las comunicaciones con los ponentes que se han realizado.
Horas totales: 4:30 horas.