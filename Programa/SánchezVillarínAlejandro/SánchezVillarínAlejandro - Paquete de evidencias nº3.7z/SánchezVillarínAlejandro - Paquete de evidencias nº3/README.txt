En este paquete se presentan las evidencias de las reuniones para la coordinaci�n de los ordenadores con la asociaci�n GUMUS.
Horas totales: 1:00 horas.