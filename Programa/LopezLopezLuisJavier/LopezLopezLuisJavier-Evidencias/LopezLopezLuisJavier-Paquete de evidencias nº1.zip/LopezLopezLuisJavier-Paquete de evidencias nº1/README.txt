-Descripci�n del paquete:

 EN este paquete se incluyen las evidencias correspondientes al proceso de prearaci�n
de las preguntas para la actividad del trivial.


-Total horas del paquete:      11,5 Horas