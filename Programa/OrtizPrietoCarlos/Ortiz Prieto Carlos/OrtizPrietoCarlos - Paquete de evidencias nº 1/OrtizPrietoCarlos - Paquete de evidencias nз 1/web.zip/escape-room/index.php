<!DOCTYPE html>
<html>
	<head>
		<title>Software Room</title>
	
	</head>
	
	<body>
		
		
		<?php 
			header('Location: Mi-confereNciA-IngenieriA-dEL-softwAre/index.php');
		?>
	</body>
</html>