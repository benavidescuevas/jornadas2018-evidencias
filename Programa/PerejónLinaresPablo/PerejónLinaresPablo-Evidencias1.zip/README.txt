Evidencias: 
 -Exposici�n sobre Planes de estudio de Ing. Inform�tica
 -Reuni�n para la Gymkhana del d�a 13 de noviembre
 -Asistencia a la Gymkhana del d�a 13 de novimebre como ayudante.

Horas totales: 9H 10M