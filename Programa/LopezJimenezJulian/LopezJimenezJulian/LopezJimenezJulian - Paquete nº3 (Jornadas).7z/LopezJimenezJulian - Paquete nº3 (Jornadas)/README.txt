Evidencia N�1 - Asistencia		-->   6 horas 
Evidencia N�2 - Taller Ni�os Scratch	-->   2 horas y 10 minutos
Evidencia N�3 - Ayuda Catering Desayuno	-->   2 horas y 15 minutos
Evidencia N�4 - Catering Mesa Redonda	-->   3 horas y 30 minutos

Horas totales: 13 horas y 55 minutos

Evidencias relacionadas con mi participacion activa durante el transcurso de las jornadas. Estas incluyen las asistencias a ponencias, ayuda tanto en el catering del desayuno/networking como en el catering de la mesa redonda, por ultimo ayud� a la realizacion del taller de los ni�os con Scratch, experiencia muy gratificante de como ni�os de edad temprana, con explicaciones muy simples y un entorno visual entrenido, son capaces de programar.