En este paquete solo se incluye una evidencia (pues ha supuesto 9 horas) que es la elaboración del código para el problema de TOURNAMETSII.

Total de horas: 9 horas.

NOTA: existe un enlace para poder descargar el código, está adjunto en la evidencia.
