N�mero total de horas: 9 horas 50 minutos

Este paquete tiene 5 evidencias. Son las siguientes:
- Evidencia sobre la creaci�n de microtrabajos.
- Evidencia sobre la creaci�n de los diferentes documentos del comit� de Programa.
- Dos evidencias sobre dos reuniones de Programa.
- Reuni�n de Coordinaci�n.

Para facilitar la organizaci�n de documentos anexos, he creado 5 carpetas para las diferentes evidencias.