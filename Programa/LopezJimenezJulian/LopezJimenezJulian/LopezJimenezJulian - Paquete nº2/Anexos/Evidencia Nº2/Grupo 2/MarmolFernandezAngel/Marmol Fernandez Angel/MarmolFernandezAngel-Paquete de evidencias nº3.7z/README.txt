N�mero total de horas: 8 horas 30 minutos

Este paquete tiene 5 evidencias de car�cter miscel�neo. Son las siguientes:
- Evidencia sobre la reuni�n de organizaci�n de la exposici�n.
- Evidencia sobre la organizaci�n de materiales para la exposici�n.
- Reuni�n de Coordinaci�n tras las jornadas
- Reuni�n de Presidencia en la que estuvimos presentes el coordinador de Log�stica y yo.
- Evidencia sobre la puesta en contacto con los ponentes.

Para facilitar la organizaci�n de documentos anexos, he creado 5 carpetas para las diferentes evidencias.