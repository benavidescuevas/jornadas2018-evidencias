-Descripci�n del paquete:

 EN este paquete se incluyen las evidencias correspondientes Al desarrollo de la actividAD DEL TRIVIAL 

-Total horas del paquete:    9 Horas