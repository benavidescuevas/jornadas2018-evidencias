Carlos Manuel Cabello Colmenares, grupo 2.
Comit� de Programa

He estado presente en las reuniones de comit� de programa del grupo 2, elaborando actas de estas reuniones
y participando activamente en la organizaci�n de las jornadas. Particip� activamente de la
ejecuci�n de la idea de la exposici�n de SSOO antiguos y tambi�n consegu� una ponencia sobre Blockchain
de la mano de Diego Fern�ndez Barrera.

En total he podido contabilizarme 19'6h.
Adicionalmente, he vendido 10 papeletas para el sorteo de InnoSoft Days 
que tambi�n contabilizar�an como tiempo de trabajo.

Mis evidencias se dividen en 3 paquetes:
	Paquete 1: Reuniones y Colaboracion como ayudante de secretario
		*Evidencia 1
		*Evidencia 2
		*Evidencia 3
		*Evidencia 4
	Paquete 2: Organizaci�n y Exposici�n de Ordenadores y SSOO Antiguos
		*Evidencia 5
		*Evidencia 6
	Paquete 3: Contacto, Comunicaciones y Recepci�n de Ponente
		*Evidencia 7




