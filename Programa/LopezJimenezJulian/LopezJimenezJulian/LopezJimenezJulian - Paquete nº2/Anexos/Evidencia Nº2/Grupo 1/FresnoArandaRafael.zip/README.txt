El trabajo realizado en las jornadas se ha dividido en cuatro paquetes diferentes:
- El primero contiene las evidencias correspondientes a las reuniones que se realizaron en el comité de programa para proponer y votar ideas.
- El segundo contiene todo lo relacionado con el taller de App Inventor realizado para niños de primero y segundo de secundaria: la familiarización con la herramienta, el desarrollo de una aplicación de ejemplo y la preparación y el desarrollo del taller.
- El tercero contiene las evidencias relacionadas con la charla "OAS-Tools/Generator: construcción automatizada de APIs RESTful con gestión de la seguridad": preparación, despliegue de APIs de ejemplo y desarrollo de la charla.
- El cuarto contiene únicamente la asistencia a la conferencia "Los estudios de Ingeniería de Software: pasado, presente y futuro".
Horas totales: 35.3
