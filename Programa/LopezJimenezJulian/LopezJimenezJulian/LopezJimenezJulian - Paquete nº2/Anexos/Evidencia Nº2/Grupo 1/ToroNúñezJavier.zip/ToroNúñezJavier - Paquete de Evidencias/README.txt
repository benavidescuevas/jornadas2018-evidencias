Horas totales invertidas:

	5 horas (taller ni�os)*2 + 4 horas (torneo) + 1 hora (Gumus) + 1h y 15 min (soft room) + 50 min (asistencia) + 50 min (asistencia) + 1h 20 min * 2 (mesa redonda) 	+ 1h 45 min (reuni�n)

Recuento total:

	22 h y 20 min 