En total, yo, Carlos Casta�o del Castillo he empleado 27 horas de trabajo f�sico.
Todo esto sin contar las horas de chat+e-mails durante estas semanas, las cuales
podr�an ser 2 horas m�s.

Mis evidencias se basan en reuniones de creaci�n y gesti�n del torneo de programaci�n
TOURNAMETSII.

Ser moderador en dos eventos: un taller y una charla el martes 13N.

Gerente principal del torneo TOURNAMETSII.

Gesti�n de los repositorios y documentaci�n referente en Google Drive por las diferentes
pruebas.

Realizaci�n de c�digo para resolver las diferentes pruebas y la creaci�n de sus 
enunciados.

Asistencia a eventos como la 'Mesa Redonda'.