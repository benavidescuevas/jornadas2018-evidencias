· En el paquete de trabajo 1, se añaden las evidencias referentes a asistencias,
  reuniones y microtrabajos. Contiene un total de 11 horas y 40 minutos.
· En el paquete de trabajo 2, se añaden las evidencias referentes al taller de
  adolescentes. Contiene un total de 15 horas.

En total, se ha trabajado un total de 26 horas y 40 minutos.