	En este Paquete de evidencias nº 3, se presentan todas las evidencias relacionadas con la ayuda al encargado del Trivial, Rubén Toro, a crear los distintos
Kahoot y a estar encargado del stand en las jornadas. Estas evidencias son la Evidencia 10 - Realización de preguntas, la cual recoge la búsqueda de preguntas
para incluir en dos Kahoot más; la Evidencia 11 - Videoconferencia de preparación del Trivial, la cual recoge la realización de una reunión por videoconferencia
para revisar todas las preguntas incluidas en los distintos Kahoot, además de acordar la normativa para la entrega de los premios, y ver qué necesidades había para
montar el stand; y la Evidencia 12 - Encargado del stand del Trivial, la cual recoge el trabajo realizado al montar el stand, y estar encargado de él durante casi
todo el martes 13, realizando en este stand más tareas aparte del Trivial.

	Además, también se ha incluido la evidencia relacionada con las horas de asistencia, la Evidencia 13 - Asistencia a las jornadas, la cual incluye las cuatro
conferencias a las que se ha asistido el lunes y el viernes de las jornadas, aparte de hacer referencia a que las horas de encargado del martes también cuentan
para dicha asistencia (hasta un máximo de 6 horas, más una hora extra por asistir a la mesa redonda del viernes, haciendo un total de 7 horas). Por tanto, como dicha evidencia también recoge la asistencia a la mesa redonda (la cual vale como 1 hora y 40 minutos de trabajo extra en las jornadas, aparte de la hora que contabiliza como asistencia), el tiempo total de ésta es de 8 horas y 40 minutos.

	El desglose del tiempo empleado en cada actividad de este paquete sería el siguiente:
		- Realización de preguntas 						-> 1 hora y 9 minutos 	(12 de noviembre)
		- Videoconferencia de preparación del Trivial	-> 1 hora y 14 minutos 	(12 de noviembre)
		- Encargado del stand del Trivial 				-> 7 horas y 40 minutos (13 de noviembre)
		- Asistencia a las jornadas 					-> 8 horas y 40 minutos (13 de noviembre)

	En resumen, este Paquete de evidencias nº 3 recoge las evidencias propias del trabajo en el Trivial, y la asistencia física a las jornadas (ya sea como oyente
o como encargado). El paquete contiene 4 de las 13 evidencias totales (un 30,77% del total), que equivalen a 18 horas y 43 minutos de las 41 horas y 11 minutos 
totales (un 45,45% del total). 