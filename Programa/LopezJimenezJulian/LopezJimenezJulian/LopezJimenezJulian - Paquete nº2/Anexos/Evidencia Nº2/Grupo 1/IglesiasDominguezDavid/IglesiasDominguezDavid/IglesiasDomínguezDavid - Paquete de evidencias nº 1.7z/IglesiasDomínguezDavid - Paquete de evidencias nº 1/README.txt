	En este Paquete de evidencias nº 1, se presentan todas las evidencias relacionadas con la primera tarea asignada (la que más prioridad tenía) por el comité de 
programa, es decir, el contacto con los distintos ponentes para poder realizar el horario. Estas evidencias son la Evidencia 2 - Contacto con los ponentes, la cual
recoge todos los contactos que se han realizado con los distintos ponentes asignados, y la Evidencia 3 - Búsqueda de grupos de mujeres, la cual recoge la búsqueda 
de un grupo de mujeres en la Ingeniería Informática que pudieran realizar una charla, debido a que Geek and Tech Girls no podían.

	Además, también se ha incluido las evidencias relacionadas con las dos reuniones propias del comité de programa. Éstas son la Evidencia 1 - Reunión de inicio
del comité, que fue la primera reunión del comité de programa para asignar tareas y aprobar iniciativas, y la Evidencia 4 - Segunda reunión del comité, que fue la
segunda y última reunión del comité de programa al completo, para asignar nuevas tareas y aprobar el horario.

	El desglose del tiempo empleado en cada actividad de este paquete sería el siguiente:
		- Reunión de inicio del comité 	-> 2 horas 				(10 de octubre)
		- Contacto con los ponentes 	-> 1 hora y 15 minutos 	(13 de octubre al 13 de noviembre)
		- Búsqueda de grupo de mujeres 	-> 30 minutos 			(16 de octubre)
		- Segunda reunión del comité 	-> 1 hora 				(24 de octubre)

	En resumen, este Paquete de evidencias nº 1 recoge las evidencias relacionadas con el inicio de la organización de las jornadas. El paquete contiene 4 de las 
13 evidencias totales (un 30,77% del total), que equivalen a 4 horas y 45 minutos de las 41 horas y 11 minutos totales (un 11,53% del total). A pesar de ser el paquete con menos horas totales, es el que contiene la actividad con más días de duración (Contacto con los ponentes - del 13 de octubre al 9 de noviembre), la cual se considera la más importante de todas las actividades realizadas, ya que era indispensable contar con ponentes para realizar las jornadas.