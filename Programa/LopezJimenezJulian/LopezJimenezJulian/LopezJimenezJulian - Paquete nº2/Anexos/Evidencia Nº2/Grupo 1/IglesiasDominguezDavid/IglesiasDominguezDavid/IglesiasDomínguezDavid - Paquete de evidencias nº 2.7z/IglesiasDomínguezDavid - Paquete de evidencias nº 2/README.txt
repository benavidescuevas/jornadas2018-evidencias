	En este Paquete de evidencias nº 2, se presentan todas las evidencias relacionadas con la organización del torneo de programación de las jornadas, llamado
TOURNAMETSII. Estas evidencias son la Evidencia 5 - Reunión inicial de TOURNAMETSII, la cual recoge la primera reunión realizada para presentar la idea del torneo
y proponer los primeros bocetos de retos y organización del torneo; la Evidencia 6 - Búsqueda de retos, la cual recoge la búsqueda posterior de ideas para los
retos del torneo; la Evidencia 7 - Redacción de enunciados, la cual recoge la redacción de los enunciados de los retos encontrados en la búsqueda anterior; y la
Evidencia 8 - Resolución de retos, la cual recoge la realización de la solución de los distintos retos encontrados anteriormente.

	Además, también se ha incluido la evidencia relacionada con ser encargado y jurado del TOURNAMETSII. Esta evidencia es la Evidencia 9 - Encargado de
TOURNAMETSII, la cual recoge el trabajo realizado en los días de las jornadas para organizar la sala del torneo, hacer de jurado, y recoger la sala al final.

	El desglose del tiempo empleado en cada actividad de este paquete sería el siguiente:
		- Reunión inicial de TOURNAMETSII 	-> 1 hora y 34 minutos 	(17 de octubre)
		- Búsqueda de retos 				-> 1 hora y 5 minutos 	(7 de noviembre al 8 de noviembre)
		- Redacción de enunciados 			-> 3 horas y 13 minutos (8 de noviembre al 10 de noviembre)
		- Resolución de retos 				-> 8 horas y 21 minutos (8 de noviembre al 10 de noviembre)
		- Encargado de TOURNAMETSII			-> 3 horas y 30 minutos	(13 de noviembre)

	En resumen, este Paquete de evidencias nº 2 recoge únicamente las evidencias propias del trabajo de TOURNAMETSII. El paquete contiene 5 de las 13 evidencias 
totales (un 38,46% del total), que equivalen a 17 horas y 43 minutos de las 41 horas y 11 minutos totales (un 43,02% del total). 