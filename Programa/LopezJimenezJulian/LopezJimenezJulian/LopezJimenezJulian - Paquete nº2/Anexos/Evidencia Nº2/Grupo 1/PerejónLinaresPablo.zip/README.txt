Entregados un paquete de evidencias, con tres evidencias. Son microtrabajos hechos para el comit� de Programa,
relacionados con la Gymkhana del d�a 13 de Noviembre y con una exposici�n sobre los planes de estudio de la Ing. Inform�tica
desde sus inicios hasta el d�a de hoy.

Horal totales: 9H 10M