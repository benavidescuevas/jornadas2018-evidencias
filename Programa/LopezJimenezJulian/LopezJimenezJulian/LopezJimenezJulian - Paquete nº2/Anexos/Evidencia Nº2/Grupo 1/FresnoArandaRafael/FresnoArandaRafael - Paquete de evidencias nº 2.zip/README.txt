Este paquete contiene las evidencias correspondientes a la preparación y el desarrollo del taller de App Inventor, realizado para niños de primero y segundo de secundaria.
Horas totales: 21
