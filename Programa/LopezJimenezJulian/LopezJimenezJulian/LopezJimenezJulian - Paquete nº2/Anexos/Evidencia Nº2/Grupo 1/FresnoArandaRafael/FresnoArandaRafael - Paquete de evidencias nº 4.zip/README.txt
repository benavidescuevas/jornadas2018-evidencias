Este paquete contiene únicamente la evidencia correspondiente a la asistencia a la conferencia "Los estudios de Ingeniería de Software: pasado, presente y futuro".
Horas totales: 2
