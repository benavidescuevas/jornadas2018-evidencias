Mi trabajo se ha llevado a cabo fundamentalmente en la creaci�n y desarrollo del escape room, el contacto con Bitnami, la b�squeda de merchandising.

El n�mero de horas invertido es de 50:54 horas, contando tambi�n con que 5 de las horas de asistencias son de trabajo, saldr�a un total de 55:54 horas.
