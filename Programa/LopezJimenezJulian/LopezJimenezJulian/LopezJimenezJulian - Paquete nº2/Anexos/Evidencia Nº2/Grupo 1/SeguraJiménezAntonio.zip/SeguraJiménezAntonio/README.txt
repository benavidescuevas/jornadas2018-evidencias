Tal y como nos piden para documentar todo lo realizado 
durante las jornadas, he realizado y recogido toda la 
informaci�n que he podido para verificar que mi trabajo
es real y que quede constancia de ello. La recogida y 
clasificaci�n de todos los documentos y ver donde ponerlos 
y pedir las im�genes y actas me he consumido bastante tiempo. 
He decidido dividir las evidencias en 4 zip, el primero me 
centro m�s en la tarea de investigaci�n y propuestas, el 
segundo en las reuniones, el tercero en la realizaci�n del
 juego y el cuarto en la asistencia y trabajo en las jornadas. 
Todos contienes 4 evidencias excepto el cuarto que tiene 3.


Horas paquete 1: 3 horas 40 minutos
Horas paquete 2: 4 horas 35 minutos
Horas paquete 3: 5 horas 45 minutos
Horas paquete 4: 21 horas 20 minutos

Horas totales: 35 hora y 20 minutos