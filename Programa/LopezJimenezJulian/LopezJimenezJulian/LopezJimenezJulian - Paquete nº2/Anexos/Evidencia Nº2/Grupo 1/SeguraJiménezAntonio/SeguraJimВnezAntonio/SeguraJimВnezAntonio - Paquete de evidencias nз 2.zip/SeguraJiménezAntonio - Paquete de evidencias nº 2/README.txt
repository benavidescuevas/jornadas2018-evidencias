He decidido poner aqu� las evidencias de las reuniones tanto
de programa como del taller de ni�os.

Horas totales: 4 horas y 35 minutos

