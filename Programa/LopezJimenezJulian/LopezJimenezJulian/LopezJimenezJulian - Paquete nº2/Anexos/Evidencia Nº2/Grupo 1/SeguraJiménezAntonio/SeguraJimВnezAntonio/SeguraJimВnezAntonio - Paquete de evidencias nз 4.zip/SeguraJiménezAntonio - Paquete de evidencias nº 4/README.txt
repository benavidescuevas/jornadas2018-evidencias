He puesto aqu� las evidencia de la asistencia y trabajo en las jornadas
y la documentaci�n de la misma con las evidencias.

Horas totales: 21 horas y 20 minutos 