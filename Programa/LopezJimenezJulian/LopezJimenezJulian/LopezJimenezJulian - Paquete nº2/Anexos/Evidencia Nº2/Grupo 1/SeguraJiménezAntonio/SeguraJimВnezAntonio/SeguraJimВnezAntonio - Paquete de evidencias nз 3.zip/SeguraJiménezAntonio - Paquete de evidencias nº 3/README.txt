He decidido poner aqu� las evidencias de la realizaci�n del juego,
la realizaci�n del propio taller y la documentaci�n del mismo.

Horas totales 5 horas y 45 minutos.