En este paquete van incluidos las evidencias relacionadas con el taller de adolescentes.
En total, en este paquete se ha trabajado un total de 15 horas.