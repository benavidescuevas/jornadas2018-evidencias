-Realizaci�n de preguntas para stand de Trivia (Kahoot): 3h 25 min
-Supervisi�n de sala de estudios MT0010: 2h
-Ayuda en la Gymkhana MT0001: 2h 30 min
-Encargado de Trivia en Stand (Kahoot) MT0016: 4h 15min
-Participaci�n en taller de ni�os MT0017: 2h 7min

Horas totales: 14 h 17 min