Se adjuntan 6 Documentos:

Los 3 primeros corresponden al trabajo realizado dentro de la gesti�n del programa.
1 Reuni�n programa 1				1 HORA
2 Reuni�n Programa 2				1 HORA
3 Creaci�n del horario				4 HORAS

Los 3 �ltimos corresponden a la realizaci�n de Tournamentsii
4 Reuni�n					1'5 HORAS
5 Asistencia como gerente			4 HORAS
6 Trabajo realizado para el torneo 		4 HORAS


HORAS TOTALES:
15,5 HORAS

HORAS DE ASISTENCIA:
6 HORAS