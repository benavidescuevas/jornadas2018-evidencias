En este paquete he incluido las evidencias que hacen referencia a un conjunto de actividades miscel�neas:
	1) B�squeda y recogida del merchandising.
	2) Contacto con bitnami.
	3) Creaci�n de requisitos de una app que mejore la coordinaci�n de los comit�s de las jornadas.
	4) Participaci�n en el concurso de Bitnami
	5) Primera reuni�n de programa
	6) Segunda reuni�n de programa

La duraci�n de estas evidencias es de: 11:52 horas.
