En este paquete he incluido las evidencias que hacen referencia a la preparaci�n del escape room:
	1) La creaci�n de las pruebas del ordenador.
	2) La creaci�n de otras pruebas, as� como la evoluci�n de estas.

La duraci�n de estas evidencias es de: 16:53 horas.
