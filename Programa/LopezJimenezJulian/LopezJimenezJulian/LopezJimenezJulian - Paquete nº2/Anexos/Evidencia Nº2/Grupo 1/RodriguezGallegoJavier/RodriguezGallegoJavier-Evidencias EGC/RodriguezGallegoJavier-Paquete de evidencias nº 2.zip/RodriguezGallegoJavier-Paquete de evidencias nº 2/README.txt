---------------------------------------------------------------------
RESUMEN de evidencias del paquete nº 2:

Gymkhana --------------------------------> 17:50h
Trabajos presenciales en jornadas -------> 05:15h

Tiempo total dedicado en este paquete ---> 23:05h
Tiempo total dedicado -------------------> 41:25h
---------------------------------------------------------------------

DETALLADO:

12 de Octubre
-Propuesta de pruebas para Gymkhana: de 17:40 a 19:00 ------> 1:20h

13 de Octubre
-Comienzo de planificación de Gymkhana: 19:00 a 20:05 ------> 1:05h

18 de Octubre
-Documentación de planificación de Gymkhana: 16:00 a 18:35 -> 2:35h
-Documentación para la Gymkhana: 18:35 a 19:05 -------------> 0:30h

28 de Octubre
-Realización de pruebas para la Gymkhana: 16:05 a 19:05 ----> 3:00h

30 de Octubre
-Realización de pruebas para la Gymkhana: 16:30 a 17:10 ----> 0:40h

31 de Octubre
-Realización de pruebas para la Gymkhana: 12:40 a 13:10 ----> 0:30h

2 de Noviembre
-Realización de pruebas para la Gymkhana: 12:00 a 12:20 ----> 0:20h

6 de Noviembre
-Promoción de la Gymkhana: 17:30 a 18:00 -------------------> 0:30h

7 de Noviembre
-Realización de pruebas para la Gymkhana: 16:40 a 17:40 ----> 1:00h
-Realización de pruebas para la Gymkhana: 20:00 a 1:00 -----> 5:00h

11 de Noviembre
-Realización de pruebas para la Gymkhana: 19:40 a 21:00 ----> 1:20h

13 de Noviembre
-Preparación de la Gymkhana: 11:55 a 12:30 -----------------> 0:35h
-Gymkhana innosoft: 12:30 a 14:30 --------------------------> 2:00h

16 de Noviembre
-Mesa Redonda: 11:20 a 12:40 -------------------------------> 2:40h*

*Cuentan horas dobles

---------------------------------------------------------------------