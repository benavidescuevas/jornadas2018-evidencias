﻿---------------------------------------------------------------------
RESUMEN de evidencias del paquete nº 1:

Propuesta de ideas para el programa ---> 02:40h
Reuniones -----------------------------> 05:25h
Contacto con antiguos alumnos ---------> 04:15h
Asistencia ----------------------------> 06:00h

Tiempo total dedicado en este paquete -> 18:20h
Tiempo total dedicado -----------------> 41:25h
---------------------------------------------------------------------

DETALLADO:

5 de Octubre
-Propuesta de ideas: 17:30 a 19:00 -----------------------> 1:30h
-Propuesta de ideas: 21:30 a 21:40 -----------------------> 0:10h

9 de Octubre
-Propuesta de ideas: 17:30 a 18:33 -----------------------> 1:00h

10 de Octubre
-Reunión de programa: de 11:15 a 13:20 -------------------> 2:05h

16 de Octubre
-Búsqueda de antiguos alumnos: de 21:30 a 22:20 ----------> 0:50h

17 de Octubre
-Búsqueda de antiguos alumnos: 12:50 a 14:00 -------------> 1:10h
-Contacto con antiguos alumnos: 19:25 a 21:40 ------------> 2:15h

12 de Noviembre
-Reunión de coordinación en Gymkhana: 10:30 a 12:10 -------> 1:40h
-Reunión de coordinación en Gymkhana: 15:30 a 17:10 -------> 1:40h
-Asistencia a charla del director: 19:30 a 20:20 ---------> 0:50h

13 de Noviembre
-Networking/Desayuno: 10:10 a 10:40 ----------------------> 0:30h
-Asistencia a kahoot: 10:40 a 11:55 ----------------------> 1:15h
-Asistencia a conferencia blockchain: 15:30 a 17:20 ------> 1:50h
-Competición de ideas open source Bitnami: 18:30 a 19:30 -> 2:00h
-Kahoot igualdad: 20:00 a 20:30 --------------------------> 0:30h
-Escape Room de coordinadores: 20:40 a 21:15 -------------> 0:45h

---------------------------------------------------------------------