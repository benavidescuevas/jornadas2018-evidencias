Evidencia N�1 - Reuniones Generales	--> 5 horas y 20 minutos
Evidencia N�2 - Reuniones Programa	--> 5 horas y 00 minutos
Evidencia N�3 - Reuniones Secretaria	--> 1 hora  y 30 minutos

Horas totales: 11 horas y 50 minutos

Evidencias relacionadas con una de mis labores como secretario. En ellas se incluyen reuniones generales, reuniones con el comit� de programa y la realizacion de las actas de estas, y por ultimo una reunion de los secretarios.