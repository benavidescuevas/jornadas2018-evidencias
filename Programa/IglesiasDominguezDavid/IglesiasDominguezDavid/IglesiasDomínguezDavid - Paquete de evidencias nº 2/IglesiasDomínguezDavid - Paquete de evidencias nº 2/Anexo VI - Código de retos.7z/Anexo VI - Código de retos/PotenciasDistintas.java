package pendientes;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

public class PotenciasDistintas {
	
	public static int getPotenciasDistintas() {
		Set<BigInteger> potenciasGeneradas = new HashSet<>();
		for (int a = 2; a <= 100; a++) {
			for (int b = 2; b <= 100; b++) {
				potenciasGeneradas.add(BigInteger.valueOf(a).pow(b));
			}
		}
		return potenciasGeneradas.size();
	}

}
