package pendientes;

public class Coordenadas {
	
	private int x;
	private int y;
	
	Coordenadas(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return this.x;
	}
	
	public void setX(final int x) {
		this.x = x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public void setY(final int y) {
		this.y = y;
	}
	
	public int getDistancia(Coordenadas c) {
		return Math.abs(this.x - c.x) + Math.abs(this.y - c.y); 
	}
	
}
