package pendientes;

import java.util.Arrays;

public class BalanzaEquilibrada {
	
	public static String getBalanzaEquilibrada(int[] pesosIniciales, int[] pesosDisponibles) {
		int longitud = pesosDisponibles.length;
		int[] disponibles = Arrays.copyOf(pesosDisponibles, longitud + 1);
		disponibles[longitud] = 0;
		
		Arrays.sort(pesosIniciales);
		Arrays.sort(disponibles);
		if (pesosIniciales[0] != pesosIniciales[1]) {
			for (int i = 0; i < disponibles.length; i++) {
				for (int j = i+1; j < disponibles.length; j++) {
					if (pesosIniciales[0] + disponibles[i] == pesosIniciales[1] + disponibles[j] ||
							pesosIniciales[0] + disponibles[j] == pesosIniciales[1] + disponibles[i]) {
						return (disponibles[i] == 0 ? "" : disponibles[i]) +
								(disponibles[i] != 0 && disponibles[j] != 0 ? "," : "") +
								(disponibles[j] == 0 ? "" : disponibles[j]);
					}
				}
			}
			int i = 0;
			int j = disponibles.length - 1;
			while (i < j) {
				if (disponibles[i] + disponibles[j] + pesosIniciales[0] > pesosIniciales[1]) {
					j--;
				} else if (disponibles[i] + disponibles[j] + pesosIniciales[0] < pesosIniciales[1]) {
					i++;
				} else {
					return (disponibles[i] == 0 ? "" : disponibles[i]) +
							(disponibles[i] != 0 && disponibles[j] != 0 ? "," : "") +
							(disponibles[j] == 0 ? "" : disponibles[j]);
				}
			}
		}
		
		return "Imposible";
	}

}
