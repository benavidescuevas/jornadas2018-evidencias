package pendientes;

import java.util.List;
import java.util.ArrayList;

public class EnemigoMasCercano {
	
	public static int getEnemigoMasCercano(List<String> matriz) {
//		 Inicializamos tanto la variable para guardar la posici�n del aliado (representado con un 1)
//		 como las posiciones de los enemigos (representados por un 2)
		Coordenadas aliado = new Coordenadas(-1, -1);
		List<Coordenadas> enemigos = new ArrayList<Coordenadas>();
		int res = 0;
		
		// Recorremos la matriz comprobando si en cada posici�n hay un 1 o un 2
		for (int y = 0; y < matriz.size(); y++) {
			for (int x = 0; x < matriz.get(y).length(); x++) {
				if  (matriz.get(y).charAt(x) == '1') {
					aliado = new Coordenadas(x, y);
				} else if (matriz.get(y).charAt(x) == '2') {
					enemigos.add(new Coordenadas(x, y));
				}
			}
		}
		
		int enemigoMasCercano = Integer.MAX_VALUE;
		int indiceFinal = matriz.size() - 1;
		
		// Aumentamos en uno el indiceFinal para considerar que se puede pasar de un lado a otro de la matriz y actualizamos el aliado
		// y los enemigos
		for (int i = 0; i < indiceFinal + 1; i++) {
			Coordenadas nuevoAliado = new Coordenadas(-1, -1);
			if(aliado.getX() + i > indiceFinal) {
				nuevoAliado.setX((aliado.getX() + i - 1) % indiceFinal);
			} else {
				nuevoAliado.setX(aliado.getX() + i);
			}
			if(aliado.getY() + i > indiceFinal) {
				nuevoAliado.setY((aliado.getY() + i - 1) % indiceFinal);
			} else {
				nuevoAliado.setY(aliado.getY() + i);
			}
			
			for (Coordenadas enemigo : enemigos) {
				Coordenadas nuevoEnemigo = new Coordenadas(-1, -1);
				if(enemigo.getX() + i > indiceFinal) {
					nuevoEnemigo.setX((enemigo.getX() + i - 1) % indiceFinal);
				} else {
					nuevoEnemigo.setX(enemigo.getX() + i);
				}
				if(enemigo.getY() + i > indiceFinal) {
					nuevoEnemigo.setY((enemigo.getY() + i - 1) % indiceFinal);
				} else {
					nuevoEnemigo.setY(enemigo.getY() + i);
				}
				// Calculamos las distancias de cada enemigo respecto al aliado, una vez los que hayamos actualizado
				int distancia = nuevoAliado.getDistancia(nuevoEnemigo);
				if(distancia < enemigoMasCercano) {
					enemigoMasCercano = distancia;
				}
			}
		}
		
		if(enemigoMasCercano != Integer.MAX_VALUE) {
			res = enemigoMasCercano;
		}
		
		return res;
    
	}
	
}