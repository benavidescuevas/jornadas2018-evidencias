package pendientes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SimbolosSimples {
	
	public static boolean getSimbolosSimples(String cadena) {
		int vecesPatron1 = 0;
		Matcher patronMatch1 = Pattern.compile("(?=(\\=\\+[a-z]\\+))").matcher(cadena.toLowerCase());
		while (patronMatch1.find()) {
			vecesPatron1++;
		}
		
		int vecesPatron2 = 0;
		Matcher patronMatch2 = Pattern.compile("(?=(\\=[a-z]\\=))").matcher(cadena.toLowerCase());
		while (patronMatch2.find()) {
			vecesPatron2++;
		}
		
		int vecesPatron3 = 0;
		Matcher patronMatch3 = Pattern.compile("(?=(\\+\\=[a-z]\\=))").matcher(cadena.toLowerCase());
		while (patronMatch3.find()) {
			vecesPatron3++;
		}
		
		int vecesPatron4 = 0;
		Matcher patronMatch4 = Pattern.compile("(?=(\\=[a-z]\\=\\+))").matcher(cadena.toLowerCase());
		while (patronMatch4.find()) {
			vecesPatron4++;
		}
		
		int vecesPatron5 = 0;
		Matcher patronMatch5 = Pattern.compile("(?=(\\+\\=[a-z]\\=\\+))").matcher(cadena.toLowerCase());
		while (patronMatch5.find()) {
			vecesPatron5++;
		}
		
		int vecesLetra = 0;
		Matcher letraMatch = Pattern.compile("[a-z]").matcher(cadena.toLowerCase());
		while (letraMatch.find()) {
			vecesLetra++;
		}
		
		return vecesLetra == vecesPatron1 + vecesPatron2 - vecesPatron3 - vecesPatron4 - vecesPatron5;
	}

}
