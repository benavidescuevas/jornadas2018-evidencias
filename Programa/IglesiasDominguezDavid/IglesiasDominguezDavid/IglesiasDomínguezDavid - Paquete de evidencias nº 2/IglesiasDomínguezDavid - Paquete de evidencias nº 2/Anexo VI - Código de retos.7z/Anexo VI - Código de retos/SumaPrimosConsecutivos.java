package pendientes;

public class SumaPrimosConsecutivos {
	
	private static final int LIMITE = 1000000;
	
	public static long getSumaPrimosConsecutivos() {
		boolean[] esPrimo = listaPrimalidad(LIMITE);
		int[] primos = listaPrimos(LIMITE);
		
		long sumaMax = 0;
		int iteracionMax = -1;
		for (int i = 0; i < primos.length; i++) {
			int suma = 0;
			for (int j = i; j < primos.length; j++) {
				suma += primos[j];
				if (suma > LIMITE) {
					break;
				} else if (j - i > iteracionMax && suma > sumaMax && esPrimo[suma]) {
					sumaMax = suma;
					iteracionMax = j - i;
				}
			}
		}
		return sumaMax;
	}
	
	// Devuelve un array compuesto por true o false, dependiendo si el n�mero correspondiente a la posici�n es primo o no
	private static boolean[] listaPrimalidad(int n) {
		if (n < 0)
			throw new IllegalArgumentException("Tama�o negativo del array");
		boolean[] result = new boolean[n + 1];
		if (n >= 2)
			result[2] = true;
		for (int i = 3; i <= n; i += 2)
			result[i] = true;
		for (int i = 3, end = sqrt(n); i <= end; i += 2) {
			if (result[i]) {
				for (int j = i * i, inc = i * 2; j <= n; j += inc)
					result[j] = false;
			}
		}
		return result;
	}
	
	private static int sqrt(int x) {
		if (x < 0)
			throw new IllegalArgumentException("Ra�z cuadrada de un n�mero negativo");
		int y = 0;
		for (int i = 1 << 15; i != 0; i >>>= 1) {
			y |= i;
			if (y > 46340 || y * y > x)
				y ^= i;
		}
		return y;
	}
	
	// Devuelve un array con los primos por debajo del par�metro dado
	private static int[] listaPrimos(int n) {
		boolean[] isPrime = listaPrimalidad(n);
		int count = 0;
		for (boolean b : isPrime) {
			if (b)
				count++;
		}
		
		int[] result = new int[count];
		for (int i = 0, j = 0; i < isPrime.length; i++) {
			if (isPrime[i]) {
				result[j] = i;
				j++;
			}
		}
		return result;
	}

}
