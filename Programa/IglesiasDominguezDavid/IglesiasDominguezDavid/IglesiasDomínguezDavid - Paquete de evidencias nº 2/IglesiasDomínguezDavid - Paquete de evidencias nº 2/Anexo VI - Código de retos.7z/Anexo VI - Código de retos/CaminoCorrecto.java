package pendientes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CaminoCorrecto {
	
	private static final char[] movimientos = {'n', 's', 'o', 'e'};
	
	public static String getCaminoCorrecto(String camino) {
		int movimientosDesconocidos = camino.replaceAll("[^?]","").length();
		List<List<Character>> posiblesCombinacionesMovimientos = new ArrayList<>();
		
		for (int i = 0; i < movimientosDesconocidos; i++) {
			List<Character> listaMovimientos = new ArrayList<>();
			for (char movimiento : movimientos) {
				listaMovimientos.add(movimiento);
			}
			posiblesCombinacionesMovimientos.add(listaMovimientos);
		}
		List<String> combinacionesTotales = combinacionesTodosMovimientos(posiblesCombinacionesMovimientos);
		
		char[] camino2 = camino.toCharArray();
		for (String reemplazos : combinacionesTotales) {
			String res = comprobarSolucion(camino2, reemplazos.toCharArray());
			if (res.length() > 0) {
				return res;
			}
		}
		
		return "Sin solucion";
	}
	
	private static List<String> combinacionesTodosMovimientos(List<List<Character>> posiblesMovimientos) {
		if (posiblesMovimientos.size() == 0) {
			return new ArrayList<>();
		}
		List<Character>  subLista = posiblesMovimientos.remove(0);
		List<String> combinacionesMovimientos = new ArrayList<>();
		for (Character movimiento : subLista) {
			combinacionesMovimientos.add(movimiento.toString());
		}
		
		return constructorCombinacionesTodosMovimientos(posiblesMovimientos, combinacionesMovimientos);
	}
	
	private static List<String> constructorCombinacionesTodosMovimientos(List<List<Character>> posiblesMovimientos, List<String> combinacionesMovimientos) {
		if (posiblesMovimientos.size() == 0) {
			return combinacionesMovimientos;
		}
		List<Character> subLista = posiblesMovimientos.remove(0);
		List<String> listaMovimientos = new ArrayList<>();
		
		for (String combinacionMovimientos : combinacionesMovimientos) {
			for (Character movimiento : subLista) {
				listaMovimientos.add(movimiento + combinacionMovimientos);
			}
		}
		
		return constructorCombinacionesTodosMovimientos(posiblesMovimientos, listaMovimientos);
	}
	
	private static String comprobarSolucion(char[] camino2, char[] reemplazos) {
		char[] res = Arrays.copyOf(camino2, camino2.length);
		boolean[][] celdasPasadas = new boolean[5][5];
		int x = 0;
		int y = 0;
		int indiceReemplazo = 0;
		for (int i = 0; i < res.length; i++) {
			if (res[i] == '?') {
				res[i] = reemplazos[indiceReemplazo++];
			}
			
			if (res[i] == 'o') {
				x += -1;
			} else if (res[i] == 'e') {
				x += 1;
			}
			if (res[i] == 'n') {
				y += -1;
			} else if (res[i] == 's') {
				y += 1;
			}
			
			if (x < 0 || x > 4 || y < 0 || y > 4 || celdasPasadas[x][y]) {
				return "";
			}
			
			celdasPasadas[x][y] = true;
		}
		
		if (x == 4 && y == 4) {
			return new String(res);
		}
		
		return "";
	}
}
