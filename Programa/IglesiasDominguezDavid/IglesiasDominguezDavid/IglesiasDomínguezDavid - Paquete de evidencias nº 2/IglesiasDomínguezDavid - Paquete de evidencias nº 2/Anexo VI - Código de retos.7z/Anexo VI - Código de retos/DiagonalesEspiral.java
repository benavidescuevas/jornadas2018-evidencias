package pendientes;

public class DiagonalesEspiral {
	
	private static final int TAMA�O = 1001;
	
	public static long getDiagonalesEspiral() {
		long suma = 1;
		for (int n = 3; n <= TAMA�O; n += 2) {
			suma += 4*n*n - 6*(n - 1);
		}
		return suma;
	}

}
