package pendientes;

public class Test {
	
	public static void main(String[] args) {
		System.out.println(PalindromosDobleBase.getPalindromosDobleBase());
		
		String input11 = "4 7 1862";
		String input12 = "24 5 1865";
		String input21 = "23 6 1912";
		String input22 = "7 6 1954";
		String input31 = "17 2 2014";
		String input32 = "17 2 2015";
		String input41 = "5 8 1987";
		String input42 = "6 8 1988";
		System.out.println(NoCumpleanios.getNoCumpleanios(input11, input12));
		System.out.println(NoCumpleanios.getNoCumpleanios(input21, input22));
		System.out.println(NoCumpleanios.getNoCumpleanios(input31, input32));
		System.out.println(NoCumpleanios.getNoCumpleanios(input41, input42));
		
//		List<String> matriz = new ArrayList<String>();
//		matriz.add("0000");
//		matriz.add("2010");
//		matriz.add("0000");
//		matriz.add("2002");
//		System.out.println(EnemigoMasCercano.getEnemigoMasCercano(matriz));
//		List<String> matriz2 = new ArrayList<String>();
//		matriz2.add("000");
//		matriz2.add("100");
//		matriz2.add("200");
//		System.out.println(EnemigoMasCercano.getEnemigoMasCercano(matriz2));
		
//		System.out.println(PotenciasDistintas.getPotenciasDistintas());
		
//		System.out.println(PrimosCirculares.getPrimosCirculares());
		
//		System.out.println(DiagonalesEspiral.getDiagonalesEspiral());
		
//		int[] pesosIniciales = {13, 4};
//		int[] pesosDisponibles = {1, 2, 3, 6, 14};
//		System.out.println(BalanzaEquilibrada.getBalanzaEquilibrada(pesosIniciales, pesosDisponibles));
		
//		String input1 = "???eenese?";
//		String input2 = "sese??eesss?";
//		System.out.println(CaminoCorrecto.getCaminoCorrecto(input2));
		
//		String input1 = "informatica";
//		String input2 = "dia16112018";
//		String input3 = "26165984";
//		System.out.println(SopaLetras.getSopaLetras(input3));
		
//		String input1 = "=d=3=+s++";
//		String input2 = "f++d+";
//		System.out.println(SimbolosSimples.getSimbolosSimples(input1));
		
//		String[] input1 = new String[4];
//		input1[0] = "10100";
//		input1[1] = "10111";
//		input1[2] = "11111";
//		input1[3] = "10010";
//		System.out.println(CuadradoMaximo.getCuadradoMaximo(input1));
		
//		int input1 = 2;
//		int input2 = 5;
//		System.out.println(NumerosPentagonales.getNumerosPentagonales(input2));
		
//		String[] input1 = new String[8];
//		input1[0] = "(2,1)"; 
//		input1[1] = "(4,2)"; 
//		input1[2] = "(6,3)"; 
//		input1[3] = "(8,4)"; 
//		input1[4] = "(3,5)";
//		input1[5] = "(1,6)";
//		input1[6] = "(7,7)";
//		input1[7] = "(5,8)";
//		System.out.println(OchoReinas.getOchoReinas(input1));
		
//		System.out.println(SumaPrimosConsecutivos.getSumaPrimosConsecutivos());
		
//		System.out.println(TriangularesCodificados.getTriangularesCodificados());
		
//		System.out.println(SumaMonedas.getSumaMonedas());
		
//		System.out.println(PrimosCuadraticos.getPrimosCuadraticos());
		
//		System.out.println(CiclosRecurrentes.getCiclosRecurrente());
	
	}

}
