package pendientes;

import java.util.Arrays;

public class CuadradoMaximo {
	
	public static int getCuadradoMaximo(String[] matriz) {
		int[][] matriz2D = new int[matriz.length][];
		int indice = 0;
		
		for (String fila : matriz) {
			matriz2D[indice++] = Arrays.stream(fila.split("(?<=([01]))"))
					.mapToInt(Integer::parseInt).toArray();
		}
		
		for (int i = 1; i < matriz2D.length; i++) {
			for (int j = 1; j < matriz2D[i].length; j++) {
				if (matriz2D[i][j] == 1) {
					matriz2D[i][j] = 1 + Arrays.stream(
							new int[] {matriz2D[i-1][j], matriz2D[i-1][j-1], matriz2D[i][j-1]})
							.min().getAsInt();
				}
			}
		}
		int max = Arrays.stream(matriz2D).flatMapToInt(Arrays::stream).max().getAsInt();
		return max*max;
	}

}
