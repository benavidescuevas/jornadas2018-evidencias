package pendientes;

public class SumaMonedas {
	
	private static final int TOTAL = 200;
	private static int[] MONEDAS = {1, 2, 5, 10, 20, 50, 100, 200};
	
	public static int getSumaMonedas() {
		int[][] formasDistintas = new int[MONEDAS.length + 1][TOTAL + 1];
		formasDistintas[0][0] = 1;
		
		for (int i = 0; i < MONEDAS.length; i++) {
			int moneda = MONEDAS[i];
			for (int j = 0; j <= TOTAL; j++) {
				formasDistintas[i+1][j] = formasDistintas[i][j] + (j >= moneda ? formasDistintas[i+1][j - moneda] : 0);
			}
		}
		return formasDistintas[MONEDAS.length][TOTAL];
	}

}
