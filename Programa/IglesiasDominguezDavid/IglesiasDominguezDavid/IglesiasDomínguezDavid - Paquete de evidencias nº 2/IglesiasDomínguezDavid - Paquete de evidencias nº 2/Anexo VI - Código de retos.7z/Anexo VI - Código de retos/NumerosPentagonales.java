package pendientes;

public class NumerosPentagonales {
	
	public static int getNumerosPentagonales(int numero) {
		if (numero == 1) {
			return 1;
		}
		return ((numero - 1) * 5) + getNumerosPentagonales(numero - 1);
	}

}
