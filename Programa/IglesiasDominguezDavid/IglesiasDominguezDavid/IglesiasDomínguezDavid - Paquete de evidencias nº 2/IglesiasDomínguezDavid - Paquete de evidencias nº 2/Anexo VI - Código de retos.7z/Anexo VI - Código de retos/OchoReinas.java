package pendientes;

public class OchoReinas {
	
	public static String getOchoReinas(String[] reinas) {
		int[][] tablero = new int[8][8];
		for (String coordenadas : reinas) {
			String[] xy = coordenadas.replaceAll("[^0-9,]", "").split(",");
			tablero[Integer.parseInt(xy[1]) - 1][Integer.parseInt(xy[0]) - 1] = 1;
		}
		
		for (String coordenadas : reinas) {
			String[] xy = coordenadas.replaceAll("[^0-9,]", "").split(",");
			int x = Integer.parseInt(xy[0]) - 1;
			int y = Integer.parseInt(xy[1]) - 1;
			for (int i = 0; i < 8; i++) {
				if (i != x && tablero[y][i] == 1) {
                    return coordenadas;
                }
                if (i != y && tablero[i][x] == 1) {
                    return coordenadas;
                }
                if (i != 0 && x + i < 8 && y + i < 8 && tablero[y + i][x + i] == 1) {
                    return coordenadas;
                }
                if (i != 0 && x + i < 8 && y - i >= 0 && tablero[y - i][x + i] == 1) {
                    return coordenadas;
                }
                if (i != 0 && x - i >= 0 && y + i < 8 && tablero[y + i][x - i] == 1) {
                    return coordenadas;
                }
                if (i != 0 && x - i >= 0 && y - i >= 0 && tablero[y - i][x - i] == 1) {
                    return coordenadas;
                }
			}
		}
		
		return "True";
	}

}
