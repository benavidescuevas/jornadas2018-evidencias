package pendientes;

public class PrimosCuadraticos {
	
	public static int getPrimosCuadraticos() {
		int mejorNumero = 0;
		int mejorA = 0;
		int mejorB = 0;
		
		for (int a = -1000; a <= 1000; a++) {
			for (int b = -1000; b <= 1000; b++) {
				int numero = numeroGeneradoDePrimosConsecutivos(a, b);
				if (numero > mejorNumero) {
					mejorNumero = numero;
					mejorA = a;
					mejorB = b;
				}
			}
		}
		
		return mejorA*mejorB;
	}
	
	private static int numeroGeneradoDePrimosConsecutivos(int a, int b) {
		for (int i = 0; ; i++) {
			int n = i*i*i*a + b;
			if (n < 0 || !esPrimo(n)) {
				return i;
			}
		}
	}
	
	private static boolean esPrimo(int x) {
		if (x < 0)
			throw new IllegalArgumentException("N�mero negativo");
		if (x == 0 || x == 1)
			return false;
		else if (x == 2)
			return true;
		else {
			if (x % 2 == 0)
				return false;
			for (int i = 3, end = sqrt(x); i <= end; i += 2) {
				if (x % i == 0)
					return false;
			}
			return true;
		}
	}
	
	public static int sqrt(int x) {
		if (x < 0)
			throw new IllegalArgumentException("Ra�z cuadrada de un n�mero negativo");
		int y = 0;
		for (int i = 1 << 15; i != 0; i >>>= 1) {
			y |= i;
			if (y > 46340 || y * y > x)
				y ^= i;
		}
		return y;
	}

}
