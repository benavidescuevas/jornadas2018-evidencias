package pendientes;

import java.util.Arrays;

public class SopaLetras {
	
	public static String getSopaLetras(String sopa) {
		char[] letras = new char[sopa.length()];
		char[] numeros = new char[sopa.length()];
		int indiceLetras = 0;
		int indiceNumeros = 0;
		char[] caracteres = sopa.toCharArray();
		String resLetras = "";
		String resNumeros = "";
		
		for(int i = 0; i < sopa.length(); i++) {
			if (Character.isLetter(caracteres[i])) {
				letras[indiceLetras] = caracteres[i];
				indiceLetras++;
			} else if (Character.isDigit(caracteres[i])) {
				numeros[indiceNumeros] = caracteres[i];
				indiceNumeros++;
			}
		}
		if (indiceLetras != 0) {
			char[] copiaLetras = Arrays.copyOfRange(letras, 0, indiceLetras);
			Arrays.sort(copiaLetras);
			resLetras = new String(copiaLetras);
		}
		
		if (indiceNumeros != 0) {
			char[] copiaNumeros = Arrays.copyOfRange(numeros, 0, indiceNumeros);
			for (int i = 0; i < indiceNumeros; i++) {
				for (int j = 0; j < indiceNumeros-i-1; j++) {
					if (copiaNumeros[j] > copiaNumeros[j+1]) {
						char temp = copiaNumeros[j+1];
						copiaNumeros[j+1] = copiaNumeros[j];
						copiaNumeros[j] = temp;
					}
				}
			}
			resNumeros = new String(copiaNumeros);
		}
		
		return resLetras + resNumeros;
	}

}
