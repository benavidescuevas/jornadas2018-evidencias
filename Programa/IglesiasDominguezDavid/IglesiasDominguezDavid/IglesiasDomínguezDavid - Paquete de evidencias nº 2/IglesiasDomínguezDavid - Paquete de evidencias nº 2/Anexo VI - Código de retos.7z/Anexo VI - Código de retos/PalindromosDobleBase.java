package pendientes;

public class PalindromosDobleBase {
	
	public static String getPalindromosDobleBase() {
		long sum = 0;
		for (int i = 100; i < 1000000; i++) {
			if (esPalindromo(Integer.toString(i, 10)) && esPalindromo(Integer.toString(i, 2))) {
				sum++;
			}
		}
		return Long.toString(sum);
	}
	
	private static boolean esPalindromo(String s) {
		return s.equals(revertir(s));
	}
	
	private static String revertir(String s) {
		return new StringBuilder(s).reverse().toString();
	}

}
