package pendientes;

import java.util.HashMap;
import java.util.Map;

public class CiclosRecurrentes {
	
	public static int getCiclosRecurrente() {
		int mejorNumero = 0;
		int mejorLongitud = 0;
		
		for (int i = 1; i <= 1000; i++) {
			int longitud = getLongitudCiclo(i);
			if (longitud > mejorLongitud) {
				mejorNumero = i;
				mejorLongitud = longitud;
			}
		}
		
		return mejorNumero;
	}
	
	private static int getLongitudCiclo(int n) {
		Map<Integer,Integer> estadoAIteracion = new HashMap<>();
		int estado = 1;
		
		for (int iteracion = 0; ; iteracion++) {
			if (estadoAIteracion.containsKey(estado)) {
				return iteracion - estadoAIteracion.get(estado);
			} else {
				estadoAIteracion.put(estado, iteracion);
				estado = estado*10 % n;
			}
		}
	}

}
