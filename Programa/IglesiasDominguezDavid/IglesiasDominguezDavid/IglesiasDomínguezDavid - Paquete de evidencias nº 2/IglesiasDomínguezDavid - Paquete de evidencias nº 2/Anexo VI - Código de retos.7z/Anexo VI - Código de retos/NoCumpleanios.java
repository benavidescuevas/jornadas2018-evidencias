package pendientes;

import java.util.Calendar;

public class NoCumpleanios {
	
	public static int getNoCumpleanios(String fechaCumpleanios, String fechaActual) {
		String[] arrayCumpleanios = fechaCumpleanios.split(" ");
		String[] arrayActual = fechaActual.split(" ");
		int diaCumpleanios = Integer.parseInt(arrayCumpleanios[0]);
		int mesCumpleanios = Integer.parseInt(arrayCumpleanios[1]);
		int anioCumpleanios = Integer.parseInt(arrayCumpleanios[2]);
		int diaActual = Integer.parseInt(arrayActual[0]);
		int mesActual = Integer.parseInt(arrayActual[1]);
		int anioActual = Integer.parseInt(arrayActual[2]);
		
		if (anioCumpleanios < 1862) {
			throw new IllegalArgumentException("El anciano del Pa�s de las Maravillas naci� en 1862");
		}
		if (anioActual > 9999) {
			throw new IllegalArgumentException("No puede haber ninguna consulta que supere el a�o 9999");
		}
		
		if (diaCumpleanios == diaActual && mesCumpleanios == mesActual) {
			return 0;
		}
		
		Calendar cumpleanios = Calendar.getInstance();
		cumpleanios.set(anioCumpleanios, mesCumpleanios, diaCumpleanios);

		Calendar actual = Calendar.getInstance();
		actual.set(anioActual, mesActual, diaActual);
		
		int diasTotales = (int) ((actual.getTime().getTime() - cumpleanios.getTime().getTime())/86400000);
		
		int diasBisiestos = 0;
		for (int i = 0; i <= anioActual - anioCumpleanios; i++) {
			if (esBisiesto(anioCumpleanios + i)) {
				diasBisiestos++;
			}
		}
		
		if (esBisiesto(anioCumpleanios) && mesCumpleanios > 2) {
			diasBisiestos--;
		}
		if (esBisiesto(anioActual) && mesActual <= 2) {
			diasBisiestos--;
		}
		
		int diasDeCumpleanios = 0;
		if (mesCumpleanios == mesActual && diaCumpleanios > diaActual) {
			diasDeCumpleanios = (anioActual - anioCumpleanios - 1);
		} else if (mesCumpleanios == mesActual && diaCumpleanios < diaActual) {
			diasDeCumpleanios =(anioActual - anioCumpleanios);
		} else if (mesActual > mesCumpleanios) {
			diasDeCumpleanios = (anioActual - anioCumpleanios);
		} else if (mesCumpleanios > mesActual) {
			diasDeCumpleanios = (anioActual - anioCumpleanios - 1);
		}
		
		return diasTotales - diasBisiestos - diasDeCumpleanios;
	}
	
	private static boolean esBisiesto(int anio) {
		if ((anio % 400 == 0) || ((anio % 4 == 0) && (anio % 100 != 0))) {
			return true;
		} else {
			return false;
		}
	}

}
