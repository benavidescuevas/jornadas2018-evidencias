En este paquete se ha incluido todo lo relacionado con el trabajo para el desayuno y la comida de las jornadas.

-He creado varias secciones en la wiki, redactado una gu�a, y recopilado listados de miembros de comit�s y formas de contacto de los organizadores.

Horas totales: 3h 35m (215m)