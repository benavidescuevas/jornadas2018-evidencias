En este paquete se han incluido todo lo relacionado con la gesti�n de los microtrabajos.

1.-Creaci�n de correo web jornadasEGC2018@gmail.com y Github de las jornadasEGC2018. (30m)
2.-Gesti�n de microtrabajos. (16h 05m)

Horas totales: 16h 35m (995m)