En este paquete se han incluido todas las reuniones asistidas:

1.-Asistencia a reuni�n general del 19/10/2018: Anexo Reuni�n 1.pdf. (1h)
2.-Asistencia a reuni�n de secretar�a del 25/10/2018: Anexo Reuni�n 2.pdf. (1h 30m)
3.-Asistencia a reuni�n general del 26/10/2018: Anexo Reuni�n 3.pdf. (1h 20m)
4.-Asistencia a reuni�n general del 02/11/2018: Anexo Reuni�n 4.pdf. (1h 40m)
5.-Asistencia a reuni�n general del 07/11/2018: Anexo Reuni�n 5.pdf. (1h 10m)
6.-Asistencia a reuni�n general del 23/11/2018: Anexo Reuni�n 6.pdf. (1h 45m)

Horas totales: 8h 25m (8.4h � 505m)
