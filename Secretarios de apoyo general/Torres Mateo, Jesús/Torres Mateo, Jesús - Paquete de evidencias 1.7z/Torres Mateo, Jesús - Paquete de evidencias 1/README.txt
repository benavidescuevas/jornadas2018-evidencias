En esta carpeta son adjuntadas las evidencias de los microtrabajos de recortar los mu�ecos 
y atender el trivia stand(Este durante las jornadas), adem�s las moderaciones de las 
charlas(3 charlas), la asistencia a las reuniones y la venta de papeletas. Esto en total suma 30,5 horas.

Adem�s no est�n incluidos las 6 horas de asistencia a las jornadas, ya que moder� 3 charlas y atend� el
trivia stand, todo esto durante el horario de las mismas. Ni tampoco est� incluido como evidencia el bonus
de organizaci�n de las jornadas. Soy secretario de apoyo de las susodichas.