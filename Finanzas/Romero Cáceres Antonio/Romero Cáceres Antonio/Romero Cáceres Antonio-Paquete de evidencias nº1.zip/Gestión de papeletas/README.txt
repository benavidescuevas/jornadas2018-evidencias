En este paquete se incluye una evidencia sobre la gesti�n de papeletas (creaci�n,b�squeda de informaci�n,precios..),
una evidencia de recortar papeletas y una �ltima evidencia de venta de papeletas.
 
Horas invertidas: 12h y 30 min