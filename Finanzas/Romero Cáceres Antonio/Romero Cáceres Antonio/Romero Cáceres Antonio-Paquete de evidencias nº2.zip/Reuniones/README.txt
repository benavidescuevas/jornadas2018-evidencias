En este paquete se incluye las evidencias de reuniones a las que he podido asistir.
 
Horas invertidas: 1h 10 min