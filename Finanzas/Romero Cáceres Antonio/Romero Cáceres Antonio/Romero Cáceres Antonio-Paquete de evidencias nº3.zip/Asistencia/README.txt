En este paquete se incluye las asistencias a charlas de la jornadas.

Horas invertidas: 7h.