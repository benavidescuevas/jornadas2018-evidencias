
	Las evidencias entregadas son:
		Evidencia - 1: Carga de barriles de cerveza. 2 horas.
		Evidencia - 2: Reuni�n de seguimiento del trabajo realizado. 30 minutos.
		Evidencia - 3: Reuni�n de seguimiento del comit� de Finanzas. 1 hora.

		Papeletas vendidas: 20. 3 horas.

	Horas totales del paquete: 3 horas y 30 minutos.
	Horas totales con la venta de papeletas 6 horas y 30 minutos.