Este paquete contiene evidencias de:
- Reuni�n
- Tres micro trabajos de redes sociales ofertatos por el comit� de comunicaci�n
- Venta de papeletas

Las horas totales invertidas en las evidencias son de:

Horas de reuni�n: 0,5h

Horas de 3 microtrabajos: 6h (microtrabajo) + 4,5 (asistencia) = 10,5h

Venta de papeletas: 1h
