He hecho de supervisor de materiales de la sala de estudio, el dia martes de 8:30 a 10:30, y de 5:30 a 7:30.He realizado tambien el microtrabajo de recojida de materiales de la sala de estudios, mis evidencias entan dentro  de cada pdf.

HORAS TOTALES DE MICROTRABAJO=5