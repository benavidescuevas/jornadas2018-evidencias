He asistido a 3 reuniones de nuestro departamento de finanzas. 
HORA TOTALES DE REUNIONES=3
