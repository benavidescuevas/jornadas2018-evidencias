En esta carpeta se recoge todo lo relacionado con la reuni�n  del grupo de ayudas y burocracia.
-Horas dedicadas:1 hora