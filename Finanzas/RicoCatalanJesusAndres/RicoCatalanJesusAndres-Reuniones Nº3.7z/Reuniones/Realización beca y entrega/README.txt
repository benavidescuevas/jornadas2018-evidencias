En esta carpeta se recoge  todo lo relacionado con la realizaci�n de la beca y entrega en el pabell�n de Brasil
-Horas dedicadas: 3 horas