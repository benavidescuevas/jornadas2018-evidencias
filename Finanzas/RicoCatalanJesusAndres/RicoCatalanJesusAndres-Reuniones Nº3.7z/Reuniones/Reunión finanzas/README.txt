En esta carpeta se recoge todo lo relacionado con las reuniones de finanzas.
-Horas dedicadas:2 horas y media