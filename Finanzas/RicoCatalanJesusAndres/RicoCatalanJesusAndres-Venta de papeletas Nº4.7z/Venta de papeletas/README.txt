En esta carpeta se recoge todo lo relacionado con la venta de papeletas.
-Horas dedicas:3 horas