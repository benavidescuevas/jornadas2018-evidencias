En este paquete se encuentra todo lo relativo al trabajo realizado en microtrabajos.
-Horas dedicadas:4 horas y media.