En esta carpeta se recoge todo lo relacionado con el control de peticiones y entrega de las papeletas.
-Horas dedicadas:2 horas