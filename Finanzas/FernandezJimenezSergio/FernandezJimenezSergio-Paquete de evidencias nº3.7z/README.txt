En este paquete se incluyen las evidencias relacionadas con la organizaci�n de las jornadas de Innosoft, as� como el 
documento del presupuesto al que se hace alusi�n en ellas.

Tiempo Total: 10 Horas