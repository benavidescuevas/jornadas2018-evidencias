En este paquete se incluyen las evidencias de asistencia a las conferencias durante las jornadas, tambi�n se incluyen
como prueba de la asistencia las entradas a dichas conferencias.

Tiempo Total: 6 Horas (En realidad 7, pero el tope es 6)