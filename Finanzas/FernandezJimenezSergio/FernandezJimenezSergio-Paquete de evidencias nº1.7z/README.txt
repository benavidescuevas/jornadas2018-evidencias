En este paquete van adjuntas todas las evidencias relacionadas con las reuniones tanto del comit� de Finanzas
como las organizadas por Tesorer�a, tambi�n se incluyen las actas de las reuniones.

Tiempo total: 5 Horas 30 minutos