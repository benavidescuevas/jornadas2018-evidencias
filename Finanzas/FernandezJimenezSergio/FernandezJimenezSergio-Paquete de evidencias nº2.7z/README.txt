En este paquete se incluyen las evidencias relacionadas con la gesti�n del Presupuesto y el Registro de papeletas,
as� como la evidencia correspondiente a la venta de papeletas propia. Se incluye, adem�s, los archivos tanto de presupuesto
como del registro de las papeletas.

Tiempo total: 6 Horas 30 Minutos