En este paquete he incluido las evidencias de las reuniones del grupo de tesoreros del comit� de finanzas.
En ellas he invertido un total de 2 horas 