En este paquete he incluido las evidencias correspondiente al trabajo de las jornadas, que en mi caso
fue estar disponible y presente con parte de los fondos en caso de necesidad de cualquier gasto.
En este caso he invertido un total de 5 horas.