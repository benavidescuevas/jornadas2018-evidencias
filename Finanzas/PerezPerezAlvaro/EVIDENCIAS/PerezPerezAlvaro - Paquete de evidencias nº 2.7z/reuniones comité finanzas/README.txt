En este paquete he incluido las evidencias de las reuniones a las que he asistido del comit� de finanzas.
En ellas he invertido un total de 2,5 horas (2 horas y 30 minutos)