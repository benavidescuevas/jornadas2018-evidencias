Evidencias de patrocinios

�am-�am: 1hora 30min
Kalixto: 1hora 30min
Intelligenz: 3 horas

Total: 6 horas