Trabajos individuales para y durante la jornada

Recorte de Papeletas: 3 horas
Desayuno Jornadas: 3 horas
Comida Jornadas: 6 horas
Sorteo Papeletas: 1 hora

Total: 13 horas