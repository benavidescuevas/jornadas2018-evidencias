En este paquete va la evidencia relacionada con venta de papeletas para sufragar los gastos de las Jornadas.

Esta evidencia ocupa un total de 3 horas.