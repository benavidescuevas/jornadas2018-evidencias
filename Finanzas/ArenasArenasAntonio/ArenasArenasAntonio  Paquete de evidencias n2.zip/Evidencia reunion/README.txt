En este paquete va la evidencia relacionada con una reuni�n del comit� de Finanzas para discutir los puntos del d�a.

Esta evidencia ocupa un total de 1 hora.