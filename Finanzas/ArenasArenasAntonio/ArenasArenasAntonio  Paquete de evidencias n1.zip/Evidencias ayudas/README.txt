En este paquete van las evidencias relacionadas con la b�squeda y presentaci�n de ayudas universitarias para sufragar los gastos
de las Jornadas.

Estas evidencias ocupan un total de 4 horas.