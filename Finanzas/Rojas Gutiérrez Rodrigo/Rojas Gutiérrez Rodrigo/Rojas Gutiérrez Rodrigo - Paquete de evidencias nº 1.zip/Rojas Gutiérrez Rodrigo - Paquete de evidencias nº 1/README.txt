En el paquete de Papeletas he incluido las siguientes evidencias:

-Creaci�n de papeletas. 
 Horas invertidas: 8 horas.

-Recorte de papeletas. 
 Horas invertidas: 1 hora 30 minutos.

-Venta de papeletas.
 Horas invertidas:3 horas.

N�mero total de horas invertidas: 12 horas 30 minutos.