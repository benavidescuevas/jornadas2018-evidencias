En el paquete de Reuniones he incluido las siguientes evidencias:

-Primera reuni�n del comit� de finanzas.
Horas invertidas: 40 minutos.

-Segunda reuni�n del comit� de finanzas.
Horas invertidas: 30 minutos.

-Tercera reuni�n del comit� de finanzas.
Horas invertidas: 1 hora.

-Reuni�n con coordinador.
Horas invertidas: 25 minutos.

-Elaboraci�n documento de Buenas pr�cticas del comit� de finanzas.
Horas invertidas: 1 hora 15 minutos.

N�mero total de horas invertidas: 3 horas 50 minutos.