Paso a describir brevremente las evidencias as� como las horas invertidas.

Evidencia 1 - Logo para la asociaci�n de mujeres.
Se trataba de dise�ar un logo para la asociaci�n de mujeres.
Tiempo empleado: 1h y 30min.

Evidencia 2 - Redes sociales.
Se trataba de cubrir en la redes sociales dos conferencias para animar a la gente a asistir e informar acerca de ellas.
Tiempo empleado: 2h.

Evidencia 3 -Taller de ni�os.
Se trataba de participar en un taller de programaci�n para ni�os donde se les ense�aba a programar un juego. Estuve ayudando a los ni�os a seguir el taller para que pudiesen completar el juego propuesto.
Tiempo empleado: 5h.

Evidencia 4 - Venta de papeletas.
Se trataba de vender papeletas para colaborar con la campa�a de ingresos. Vend� 60 papeletas.
Tiempo empleado: 8h.