Evidencias: venta de papeletas, en concreto 20 papeletas.
Horas Totales: 3 horas y 15 minutos.
