Evidencias: 2 microtrabajos. El primero de supervisor y el segundo recogiendo los ordenadores.
Horas Totales: 3 horas + 2 horas de asistencia a jornadas (que se pisaban con uno de los microtrabajos)
