Evidencias: 2 reuniones de finanzas.
Horas Totales: 1 hora y 20 minutos.
