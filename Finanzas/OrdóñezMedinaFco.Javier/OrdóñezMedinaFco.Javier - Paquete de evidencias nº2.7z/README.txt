En este paquete he a�adido todas las reuniones de coordinadores.
Son un total de 8 reuniones.

Horas totales: 11 horas 33 minutos.