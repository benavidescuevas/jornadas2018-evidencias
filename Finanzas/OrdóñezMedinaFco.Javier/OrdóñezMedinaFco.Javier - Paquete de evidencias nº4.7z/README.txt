En este paquete he a�adido el excel correspondiente al seguimiento y recogida de los trabajos de los miembros de Finanzas.

Horas totales: 5h 8 min