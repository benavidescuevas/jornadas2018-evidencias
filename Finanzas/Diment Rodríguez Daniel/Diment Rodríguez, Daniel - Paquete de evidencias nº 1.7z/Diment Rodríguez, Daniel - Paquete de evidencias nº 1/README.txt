╔══════════════════════════════════════╦═════════════════╗
║       Evidencias en el paquete       ║ Horas dedicadas ║
╠══════════════════════════════════════╬═════════════════╣
║ Elaboración del documento de cuentas ║ 11,66 h         ║
║ Trabajos varios para las jornadas    ║ 9,67 h          ║
║ Total:                               ║ 21,33 h         ║
╚══════════════════════════════════════╩═════════════════╝
