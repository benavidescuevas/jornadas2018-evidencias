En este paquete de evidencias se incluyen las evidencias de fotos y videos realizados durante el 13 de noviembre.
Tambien se incluyen dos evidencias de asistencia a reuniones de log�stica.

Horas totales del paquete: 18 horas y 15 minutos