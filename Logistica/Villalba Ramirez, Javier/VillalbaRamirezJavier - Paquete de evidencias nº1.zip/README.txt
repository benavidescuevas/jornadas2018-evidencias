En este paquete de evidencias se incluyen las evidencias del simulacro de streaming y las pruebas realziadas en las aulas de audio y video previa a las jornadas.
Tambien se incluyen una evidencia de asistencia a reuni�n de log�stica y otra evidencia de la grabaci�n del video promocional de las jornadas.

Horas totales del paquete: 4 horas y 45 minutos