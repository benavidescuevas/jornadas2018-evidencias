En este paquete de evidencias se incluyen las evidencias de fotos y videos realizados durante el 12 de noviembre.
Tambien se incluyen una evidencia de asistencia a reuni�n de log�stica, una evidencia de la venta de papeletas y otra de las investigaciones realizadas para realizar streaming.

Horas totales del paquete: 10 horas y 45 minutos