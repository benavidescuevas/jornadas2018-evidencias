En el paquete actual se incluyen las siguientes evidencias:

Evidencia 4 (75 min.) -> Grabaci�n de material para la realizaci�n del v�deo promocional.

Evidencia 9 (120 min.) -> Colocaci�n de carteles de indicaci�n de las jornadas.

Evidencia 12 (160 min.) -> Sede Martes en el aula A2.16

Evidencia 14 (30 min.) ->  Ayuda Sede en el aula A2.12






Los archivos que prueban la evidencia se encuentra adjunta en el mismo documento.pdf

****LAS HORAS DE ASISTENCIA DURANTE LAS JORNADAS NO EST�N INCLUIDAS****