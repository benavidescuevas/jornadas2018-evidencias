En el paquete actual se incluyen las siguientes evidencias:

Evidencia 1 (75 min.) -> Se presupuestan los carteles para las jornadas tanto los de indicaci�n como los de publicidad.

Evidencia 2 (45 min.) -> Reuni�n Log�stica 1.

Evidencia 5 (105 min.) -> Ayud� a los compa�eros a investigar la forma de realizar el streaming durante las jornadas.

Evidencia 11 (160 min.) -> Sede en Sal�n de Grados y aula F0.10, Lunes 






Los archivos que prueban la evidencia se encuentra adjunta en el mismo documento.pdf

****LAS HORAS DE ASISTENCIA DURANTE LAS JORNADAS NO EST�N INCLUIDAS****