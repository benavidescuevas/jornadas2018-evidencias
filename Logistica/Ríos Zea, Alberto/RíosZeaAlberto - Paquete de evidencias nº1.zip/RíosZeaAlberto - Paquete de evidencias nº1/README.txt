Evidencias incluidas:

Reuni�n Log�stica I: 0,75 hrs.
Reuni�n Log�stica II: 0,75 hrs.
Venta de papeletas: 3 horas
Conferencia Escutoides: 1 h.
Taller Bitnami: 1,5 hrs.
Conferencia Frontend: 1 h.
Conferencia 100+rows: 1h.
Conferencia Blockchain:2 hrs.
Conferencia �Por qu� ellas...?: 1 h.
Competici�n de ideas Bitnami: 1,5 hrs.