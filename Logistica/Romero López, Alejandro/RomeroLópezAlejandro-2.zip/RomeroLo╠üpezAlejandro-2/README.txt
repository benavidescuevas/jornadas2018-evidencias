

- Este paquete incluye 3 evidencias:

	Horas totales: 5 horas y 40 min.

- El trabajo que he realizado, en general, ha sido hacer un documento para llevar a informar a los colegios, ayudar en el microtrabajo de programa en un taller de ni�os el martes 13 y tambi�n asistir a una reuni�n realizada en el CRAI.



