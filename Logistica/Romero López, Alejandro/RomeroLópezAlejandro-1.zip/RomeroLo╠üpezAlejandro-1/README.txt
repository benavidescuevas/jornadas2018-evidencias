

- Este paquete incluye 3 evidencias:

	Horas totales: 8 horas y 30 min.

- El trabajo que he realizado, en general, ha sido buscar colegios que quisieran traer ni�os para que acudan a los talleres organizados para los ni�os y trabajo en sede el martes 13 y tambi�n asistir a una reuni�n realizada en el CRAI.



