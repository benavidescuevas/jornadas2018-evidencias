

- Este paquete incluye 3 evidencias:

	Horas totales: 4 horas y 55 min.

- El trabajo que he realizado, en general, taller con los ni�os el jueves y trabajo en sede el viernes y tambi�n asistir a dos reuniones realizada en el CRAI.



