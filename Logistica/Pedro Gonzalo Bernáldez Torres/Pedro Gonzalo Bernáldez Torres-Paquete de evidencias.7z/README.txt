Adem�s de los trabajos y reuniones especificados en esta carpeta,
durante la jornada asist� a varias conferencias (Clara Grima y
Amador Dur�n/Jos� Luis Sevillano) y particip� en el scape room, en
el sorteo del dron y en la mesa redonda.

Horas de trabajo (microtrabajos/reuniones): 9 horas y 10 minutos
Horas totales (microtrabajos/reuniones/asistencia): 14 horas