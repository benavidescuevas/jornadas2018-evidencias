En este paquete hay evidencias de labores propias de secretario
como realizar actas de reuni�n. Tambi�n se encuentra el princi-
pio del proyecto de realizar un taller a los ni�os del colegio
Corpus Cristi.

Total de horas del paquete: 5h y 35 min 
