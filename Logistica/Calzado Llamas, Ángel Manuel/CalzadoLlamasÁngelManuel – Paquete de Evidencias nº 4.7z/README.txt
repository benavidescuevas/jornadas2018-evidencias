En este paquete hay evidencias de labores propias de secretario
como realizar actas de reuni�n. Tambi�n trabajos extra que 
realice al pensar que no llegaba a las horas como quitar car-
teles de indicaci�n y de igualdad al finalizar las jornadas.
Adem�s de facilitar la documentaci�n subiendola a la wiki y
ayudando en el taller de ni�os que el coordinador de log�s-
y yo nos encargamos de organizar.

Total de horas del paquete: 5h y 56 min