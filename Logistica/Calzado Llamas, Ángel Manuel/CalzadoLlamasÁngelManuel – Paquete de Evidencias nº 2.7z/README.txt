En este paquete hay evidencias de labores propias de secretario
como realizar actas de reuni�n. Tambi�n escucho la primera pro-
puesta de lo que va ser el registro de la asistencia con c�di-
go QR, y la labor m�s importante que es el "registro de miem-
bros de log�stica" del grupo g2 ya que el g1 lo lleva el otro
secretario.

Total de horas del paquete: 8h y 15 min 