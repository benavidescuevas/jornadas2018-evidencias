En este paquete hay evidencias de labores propias de secretario
como realizar actas de reuni�n. Tambi�n mi labor como sede y moderador en la mesa redonda

Total de horas del paquete: 4h y 45 min 