En este paquete aparte de evidencia de asistencia a la
reuni�n general, se encuentra en la evidencia 4 toda
la planificaci�n de el taller de ni�os para el cole-
gio Corpus Cristi. Tambi�n mi labor como sede en el sorteo de twitter y la recogida de horas traba-
jadas durante las jornadas necesaria para los miembros
de registro

Total de horas del paquete: 5h y 50 min