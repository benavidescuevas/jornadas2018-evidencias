- He decidido agrupar las evidencias que trataran de lo mismo en un solo documento
  ya que sino habr�a una gran cantidad de PDFs de como mucho 2 l�neas.

- En total he obtenido 5 documentos en los que se resume la labor realizada.

- Las horas totales comprendidas en las evidencias son 36.

