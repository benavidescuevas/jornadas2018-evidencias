En este paquete de incluyen las siguientes evidencias:
	- Evidencia 6: Trabajo durante la jornada del Martes 13/11/2018

Horas totales: 8 horas y 10 min
