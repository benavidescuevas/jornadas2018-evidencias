En este paquete de incluyen las siguientes evidencias:
	- Evidencia 1: Reuni�n 1 de Comit� de Log�stica
	- Evidencia 2: Reuni�n 2 de Comit� de Log�stica
	- Evidencia 3: Reuni�n 3 de Comit� de Log�stica
	- Evidencia 4: Reuni�n 4 de Comit� de Log�stica
	- Evidencia 5: Trabajo en la wiki

Horas totales: 7 horas y 15 min
