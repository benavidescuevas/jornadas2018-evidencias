EVIDENCIAS: 
(TOTAL: 5,5h)
 - Reuniones logística 2*1h --> 2h + 0,5h(Reunión lecciones aprendidas)
 - Atención al ponente --> Martes de 12 a 13:30 (1,5h)
 - Atención al ponente --> Viernes de 9:50 a 11:30 (1,5h)
 - Cesión material para realizar Streaming (Tarjeta sonido y cable extensor USB).
 