EVIDENCIAS: 
(TOTAL: 8,5h)
 - Trabajar en la Wiki --> 4h
 - Reuniones logística 2*1h --> 2h
 - Atención al ponente --> Martes de 8 a 10:30 (2,5h)
