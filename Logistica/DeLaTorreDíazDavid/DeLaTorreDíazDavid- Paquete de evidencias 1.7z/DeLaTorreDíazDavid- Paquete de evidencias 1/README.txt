En este paquete se entregan evidencias relacionadas con:

-  Reuniones de comité
- Preparación del streaming de las jornadas
- Streaming de las jornadas

Horas totales: 12h 40m