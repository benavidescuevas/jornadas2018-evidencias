En este paquete se entregan evidencias relacionadas con:

-  Reuniones de comité
- Preparación del streaming de las jornadas
- Streaming de las jornadas
- Grabación de video promocional

Horas totales: 11h 20m