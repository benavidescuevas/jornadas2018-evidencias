En este bloque he juntado todas las reuniones realizadas con el comit� de log�stica
y he a�adido dos horas de trabajo en las jornadas como moderador.

En la carpeta de documentos adjuntos se encuentran tanto las evidencias de las 
reuniones de log�stica como la hoja de moderadores final.

Total de peso de este bloque: 8 horas.