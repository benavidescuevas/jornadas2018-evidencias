Evidencia de la reuni�n del d�a 30/11 lecciones aprendidas,
Tambi�n realic� el acta de esta reunion

Horas de Trabajo:  1 hora 15 minutos

Adjunto el acta de la reunion