Evidencia de la reuni�n del d�a 12/11,
Tambi�n realic� el acta de esta reunion

Horas de Trabajo:  1 hora 30 minutos

Adjunto el acta de la reunion