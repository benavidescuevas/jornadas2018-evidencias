Evidencia de la reuni�n del d�a 23/10,
de dicha reuni�n tambi�n realic� la acta

Horas de Trabajo: 1 hora 45 minutos


Adjunto el acta de la reunion