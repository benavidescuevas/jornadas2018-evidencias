Evidencia de la reuni�n del d�a 31/10,

Horas de Trabajo:  45 minutos

Adjunto el acta de la reunion