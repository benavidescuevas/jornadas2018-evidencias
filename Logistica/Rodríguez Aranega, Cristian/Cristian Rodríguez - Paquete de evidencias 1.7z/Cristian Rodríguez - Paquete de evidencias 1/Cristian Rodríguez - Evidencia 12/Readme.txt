Evidencia de las moderaciones realizadas en las jornadas 
el lunes y viernes.

Duraci�n de las tareas: 2 horas

Se adjunta la asignaci�n de moderadores como evidencia