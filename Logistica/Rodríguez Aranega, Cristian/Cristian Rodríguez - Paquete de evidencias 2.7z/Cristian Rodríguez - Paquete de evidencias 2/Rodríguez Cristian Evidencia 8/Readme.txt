Reuni�n de presidencia 02/11

Se adjunta acta de la reuni�n.

Tiempo: 1 hora 40 minutos