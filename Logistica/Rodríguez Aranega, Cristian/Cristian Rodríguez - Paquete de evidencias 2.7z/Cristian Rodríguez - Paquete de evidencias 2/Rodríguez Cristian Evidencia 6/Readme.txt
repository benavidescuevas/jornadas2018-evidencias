Reuni�n de presidencia (gu�a de secretarios) 25/10

Se adjunta acta de la reuni�n.

Tiempo: 1 hora 30 min