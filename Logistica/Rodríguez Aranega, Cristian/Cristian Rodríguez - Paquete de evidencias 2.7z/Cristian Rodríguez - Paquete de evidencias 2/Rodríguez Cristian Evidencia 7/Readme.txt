Reuni�n de presidencia 26/10

Se adjunta acta de la reuni�n.

Tiempo: 1 hora 20 minutos