Reuni�n de presidencia 07/11

Se adjunta acta de la reuni�n.

Tiempo: 2 horas