En este paquete englobo todas las reuniones que realice con presidencia.
Adjunto una carpeta con todas las actas de las reuniones en las que particip�.

Total de este bloque: 9.5 horas
