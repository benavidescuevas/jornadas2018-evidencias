Reuni�n de presidencia 23/11

Se adjunta acta de la reuni�n.

Tiempo: 1 hora 45 minutos