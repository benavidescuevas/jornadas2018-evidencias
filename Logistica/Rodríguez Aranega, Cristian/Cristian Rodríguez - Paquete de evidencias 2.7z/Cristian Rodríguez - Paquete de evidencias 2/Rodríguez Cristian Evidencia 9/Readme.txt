Reuni�n de presidencia 07/11

Se adjunta acta de la reuni�n.

Tiempo: 1 hora 18 minutos