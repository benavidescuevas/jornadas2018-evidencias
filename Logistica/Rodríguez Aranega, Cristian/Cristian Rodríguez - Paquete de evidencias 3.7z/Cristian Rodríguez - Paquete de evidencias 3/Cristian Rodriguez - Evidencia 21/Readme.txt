Encargado de sede del aula A2.16 de 14:30 a 17:00

Ver el archivo sedes durante las jornadas.

Total de horas de este paquete: 2 horas.