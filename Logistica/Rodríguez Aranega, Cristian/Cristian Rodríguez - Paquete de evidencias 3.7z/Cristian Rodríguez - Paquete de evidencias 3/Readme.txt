En este paquete muestro las evidencias de mi trabajo en las jornadas durante el d�a del martes,
estuve 10 horas de encargado de sede del aula A2.16.

Se han dividio esas 10h en 5 paquetes de evidencias.

Al no tener fotograf�as o otro material que pueda adjuntar como evidencia dejo el fichero que
prepar� el coordinador adjudicando las sedes a los miembros de log�stica.

Ver el archivo sedes durante las jornadas donde se muestra todo el horario que realic�
El concurso de bitnami se alarg� 30 minutos m�s de la hora de cierre.

Total de horas de este paquete: 10 horas.