Encargado de sede del aula A2.16 de 19:00 a 20:00

Ver el archivo sedes durante las jornadas.

Total de horas de este paquete: 1 hora.