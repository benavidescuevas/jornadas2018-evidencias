Encargado de sede del aula A2.16 de 12:00 a 14:30

Ver el archivo sedes durante las jornadas.

Total de horas de este paquete: 2 horas 30 min.