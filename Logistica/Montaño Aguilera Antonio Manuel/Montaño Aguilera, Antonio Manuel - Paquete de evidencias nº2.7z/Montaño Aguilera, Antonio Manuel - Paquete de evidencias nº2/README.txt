En este paquete se evidencia las horas de investigaci�n para encontrar una forma eficiente de registrar la asistencia a las jornadas para calcular
las horas pertinentes de cada alumno. Adem�s se detalla la creaci�n de la cuenta de Eventbrite y el inicio de la gesti�n de los eventos en dicha cuenta.

Se recogen 6 horas en este paquete.

Por: Monta�o Aguilera, Antonio Manuel.