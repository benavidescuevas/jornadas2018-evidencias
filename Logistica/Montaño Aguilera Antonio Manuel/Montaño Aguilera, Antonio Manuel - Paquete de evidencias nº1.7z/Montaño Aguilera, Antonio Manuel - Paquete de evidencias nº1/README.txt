En este paquete se evidencian las reuniones a las que acud� en el comit� de log�stica.

En total hay recogidas 3 horas y 15 minutos.

Por: Monta�o Aguilera, Antonio Manuel.