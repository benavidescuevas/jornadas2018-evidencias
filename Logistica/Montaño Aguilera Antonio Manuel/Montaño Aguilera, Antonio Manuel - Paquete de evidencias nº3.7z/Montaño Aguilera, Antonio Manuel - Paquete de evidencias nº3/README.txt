En este paquete se evidencia todo lo que hice en las jornadas, y el simulacro que se realiz� en la clase del viernes de EGC sobre la asistencia a las
jornadas y el uso de Eventbrite, adem�s de pasar a una hoja Excel los datos de asistencia recogidos con Eventbrite.

Se recogen 19 horas y 10 minutos.

Por: Monta�o Aguilera, Antonio Manuel.