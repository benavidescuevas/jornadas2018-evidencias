Horas totales antes de la Jornada:
- 2 h 35 minutos de reuniones.
- 4 h de trabajo de investigacion.
- 6 h 27 minutos de creacion y gestion de eventos.
Total: 13 h.

Horas totales durante la Jornada:
- 3 h 40 minutos de preparacion cada en total.
- 12 h 50 minutos de trabajo de registro.
Total: 16 h 30 minutos

Horas totales despues de la Jornada:
- 30 minutos para pasar al excel la asistencia (desde eventbrite)


Total global: 30 h

---------------------------------------------------------------------

Material prestado:
- Camara SONY Handycam para la grabacion de las ponencias.
- Ordenador portatil Lenovo para la realizacion del Streaming.