PAQUETE N�5 DE EVIDENCIAS
-------------------------------------------------------
DESCRIPCI�N:
En este paquete de evidencias he a�adido la evidencia 9 (Colocaci�n carteles de indicaci�n y programa)
en la que yo y un compa�ero estuvimos colocando todos los carteles de indicaci�n y programa por toda
la facultad, las evidencias 11 y 13 en las que estuve realizando tareas de sede en las ponencias de
Clara Grima y Jes�s Bermejo, respectivamente. (Para estas evidencias adjunto un Anexo).
-------------------------------------------------------
Duraci�n Evidencia 9 = 2 horas
Duraci�n Evidencia 11 = 1 hora
Duraci�n Evidencia 13 = 1 hora
-------------------------------------------------------
Duraci�n Total del paquete n� 5 = 4 horas