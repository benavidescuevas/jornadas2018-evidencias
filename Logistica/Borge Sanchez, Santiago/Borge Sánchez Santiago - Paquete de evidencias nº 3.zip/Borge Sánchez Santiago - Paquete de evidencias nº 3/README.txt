PAQUETE N�3 DE EVIDENCIAS
-------------------------------------------------------
DESCRIPCI�N:
En este paquete de evidencias he a�adido la evidencia 4 (Dise�o de carteles de Indicaci�n)
en la que yo y un compa�ero dise�amos los carteles para indicar las aulas donde se celebrar�an
las jornadas, la evidencia 5 (Reuni�n de Log�stica) que se trata de una de las reuniones
de Log�stica a las que asist� para ser informado de las novedades con respecto a nuestro comit�,
y la evidencia 12 (Trabajo de sede) en la que estuve realizando tareas de sede en la ponencia de
Luis Pablo del �rbol(Para esta evidencia adjunto un Anexo).
-------------------------------------------------------
Duraci�n Evidencia 4 = 30 minutos
Duraci�n Evidencia 5 = 1 hora 45 minutos
Duraci�n Evidencia 12 = 1 hora 20 minutos
-------------------------------------------------------
Duraci�n Total del paquete n� 3 = 3 horas y 35 minutos