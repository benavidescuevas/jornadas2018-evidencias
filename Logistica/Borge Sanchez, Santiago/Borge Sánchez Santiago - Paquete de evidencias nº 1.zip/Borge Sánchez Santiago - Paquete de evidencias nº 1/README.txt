PAQUETE N�1 DE EVIDENCIAS
-------------------------------------------------------
DESCRIPCI�N:
En este paquete de evidencias he a�adido la evidencia 1 (Estimaci�n de carteles) en
la que yo y un compa�ero estimamos el n�mero de carteles necesarios para colocar 
por la facultad y otro lugares, la evidencia 8 (Reuni�n de Log�stica) que se trata 
de una de las reuniones de Log�stica a las que asist� para ser informado de las
novedades con respecto a nuestro comit�, y la evidencia 10 (Trabajo de sede) en la que
estuve realizando tareas de sede en la ponencia de Amador Dur�n y Jos� Luis Sevillano 
(Para esta evidencia adjunto un Anexo).
-------------------------------------------------------
Duraci�n Evidencia 1 = 1 hora
Duraci�n Evidencia 8 = 1 hora
Duraci�n Evidencia 10 = 1 hora 30 minutos
-------------------------------------------------------
Duraci�n Total del paquete n� 1 = 3 horas y 30 minutos