PAQUETE N�4 DE EVIDENCIAS
-------------------------------------------------------
DESCRIPCI�N:
En este paquete de evidencias he a�adido la evidencia 6 (Creaci�n acreditaciones) en la que
a partir del dise�o de las acreditaciones estuve creanda todas y cada una de las acreditaciones
necesarias durante el desarrollo de las jornadas, la evidencia 2 (Reuni�n de Log�stica) que se trata
de una de las reuniones de Log�stica a las que asist� para ser informado de las novedades con respecto
a nuestro comit�, y la evidencia 14 (Trabajo de sede) en la que estuve realizando tareas de sede en la
ponencia de David Barranco Alfonso y Jos� Fuentes Castillo(Para esta evidencia adjunto un Anexo).
-------------------------------------------------------
Duraci�n Evidencia 6 = 3 horas 30 minutos
Duraci�n Evidencia 2 = 45 minutos
Duraci�n Evidencia 14 = 1 hora
-------------------------------------------------------
Duraci�n Total del paquete n� 4 = 5 horas y 15 minutos