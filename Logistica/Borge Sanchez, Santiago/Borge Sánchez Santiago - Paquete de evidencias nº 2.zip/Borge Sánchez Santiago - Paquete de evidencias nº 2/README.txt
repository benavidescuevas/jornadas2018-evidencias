PAQUETE N�2 DE EVIDENCIAS
-------------------------------------------------------
DESCRIPCI�N:
En este paquete de evidencias he a�adido la evidencia 3 (Presupuesto de carteles)
en la que desarroll� un presupuesto inicial de los carteles necesarios que luego
envi� al coordinador de Log�stica, la evidencia 7 (Reuni�n de Log�stica) que se
trata de una de las reuniones de Log�stica a las que asist� para ser informado de
las novedades con respecto a nuestro comit�, y la evidencia 15 (Trabajo de sede)
en la que estuve realizando tareas de sede en la ponencia de Rafael Poveda
(Para esta evidencia adjunto un Anexo).
-------------------------------------------------------
Duraci�n Evidencia 3 = 1 hora 30 minutos
Duraci�n Evidencia 7 = 45 minutos
Duraci�n Evidencia 15 = 1 hora 10 minutos
-------------------------------------------------------
Duraci�n Total del paquete n� 2 = 3 horas y 25 minutos