README paquete de evidencias 2

Horas totales: 14 horas 20 minutos

En este paquete recojo las evidencias de las reuniones de presidencia, de la creación del documento de presupuestos de logística, de la preparar e impartir los talleres de Scratch y de probar los medios audiovisuales antes de las jornadas.