README paquete de evidencias 3

Horas totales: 15 horas

En este paquete recojo las evidencias de varias reuniones a las que he asistido, de la creación de los documentos de peticiones a la escuela y a conserjería, de la creación del documento de adjudicación de sedes y de la atención a Ramón Salado (ponente)