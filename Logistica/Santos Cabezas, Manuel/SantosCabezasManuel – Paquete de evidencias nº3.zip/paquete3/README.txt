﻿En este paquete se incluyen las siguientes evidencias: Dos reuniones de los integrantes de  logística, las distintas primeras tomas de contacto con los colegios contactados para la realización de los talleres y una reunión con el Colegio María Madre de la Iglesia.

Horas invertidas: 6 horas y 5 minutos.
