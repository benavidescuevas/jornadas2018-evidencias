﻿En este paquete se incluyen las siguientes evidencias: una reunión de los integrantes de logística, acompañar a los niños del Colegio San Miguel de Adoratrices a la ETSII para los talleres, los distintos contactos con la Directora de dicho colegio y los talleres impartidos el martes.

Horas invertidas: 5 horas y 50 minutos.
