﻿En este paquete está incluido : una reunión de los integrantes de logística ,  los ponentes atendidos durante las jornadas, una reunión con el Colegio San Miguel de Adoratrices con relación a los talleres impartidos y una evidencia respecto a los talleres impartidos el jueves.

Horas invertidas : 4 horas y 55 minutos.
