En este paquete se incluyen 4 evidencias.

Dos de las evidencias son las actas de las reuniones a las que he asistido dentro del departamento de log�stica
La segunda es de haber trabajado el Martes 13 de apoyo e en el taller a los ni�os.
La tercera trabajar de sede en Viernes 16.


En cada na de las evidencias se incluye como anexo los documentos que reflejan el trabajo. (Documentos y fotos)
Todas esas evidencias se encuentran en el mismo paquete.
N�mero de minutos en este paquete: 450 minutos -> 7 horas 30 min. 