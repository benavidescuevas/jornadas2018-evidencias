En este paquete se incluyen 3 evidencias.

La primera es hacer un documento para ir a los colegios.
La segunda ir a los colegios.
Asistir a una reuni�n dentro del departamento de log�stica.

En cada na de las evidencias se incluye como anexo los documentos que reflejan el trabajo. (Documentos y fotos)
Todas esas evidencias se encuentran en el mismo paquete.
N�mero de minutos en este paquete: 415 minutos -> 6 horas 55 min. 