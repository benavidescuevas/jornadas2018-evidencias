En este paquete se incluyen 3 evidencias.

La primera es de haber trabajado el Martes 13 de registro en la ponencia de Diego Fern�ndez Barrera
La segunda asistir a una reunion dentro del departamento de log�stica
La tercera es de haber trabajado el Jueves 15 de apoyo e en el taller a los ni�os.

En cada na de las evidencias se incluye como anexo los documentos que reflejan el trabajo. (Documentos y fotos)
Todas esas evidencias se encuentran en el mismo paquete.

N�mero de minutos en este paquete: 330 minutos -> 5 horas 30 min. 