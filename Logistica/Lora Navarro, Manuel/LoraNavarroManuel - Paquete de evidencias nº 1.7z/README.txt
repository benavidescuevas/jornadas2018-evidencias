En este paquete se incluyen 5 evidencias.

Las cinco evidencias pertenecen al departamento de log�stica del que soy miembro, estas evidencias ser�an:
1� Primera toma de contacto con los colegios (RR Casalancias, Colegio Bienaventurada Virgen Mar�a Irlandesas, Centro Privado de Ense�anza Mar�a Madre de la Iglesia) el d�a 23/10/18
2� Asistir a la reuni�n de log�stica del 23/10/18
3� Primera toma de contacto con los colegios (San Miguel Adoratrices, IES Fernando Herrera) el d�a 24/10/18
4� Asistir a la reuni�n de log�stica del 31/10/18
5� Reuni�n con la jefa de estudios del centro Privado de Ense�anza Mar�a Madre de la Iglesia

El tiempo invertido en hacer estas actividades es de 6 horas y 5 minutos
