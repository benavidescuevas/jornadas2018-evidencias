En este paquete se incluyen 3 evidencias.

De las 3 evidencias 2 (10�, 11�, 12�) pertenecen al comit� del que soy miembro, log�stica. Mientras que la 9� pertenece al comit� de programa.
10� Se acompa�a a los ni�os del colegio San Miguel Adoratrices desde este hasta la ETSII el d�a 15/10/18
11� Asistir a la reuni�n de log�stica del 06/11/18
12� Se realizan funciones de apoyo durante la realizaci�n del curso de AppInvertor2 (Curso del 13/11/12)->Micro trabajo del comit� de programa

El tiempo invertido en hacer estas actividades es de 5 horas y 15 minutos
