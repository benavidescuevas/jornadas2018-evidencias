En este paquete se incluyen 4 evidencias.

De las 4 evidencias 3 (6�, 7�, 8�) pertenecen al comit� del que soy miembro, log�stica. Mientras que la 9� pertenece al comit� de programa.
6� Se asiste a la reuni�n previamente acordada con la jefa de estudio del Colegio Concertado San Miguel Adoratrices el d�a 26/10/18
7� Asistir a la reuni�n de log�stica del 12/11/18
8� Se realiza el registro de la asistencia a la conferencia impartida por Diego Fern�ndez Barrera
9� Se realizan funciones de apoyo durante la realizaci�n del curso de Scratch (Curso del 15/11/12)->Micro trabajo del comit� de programa

El tiempo invertido en hacer estas actividades es de 6 horas y 5 minutos
