Evidencia 1: Venta de 200 papeletas (30h)

