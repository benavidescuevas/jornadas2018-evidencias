Evidencias:
- Creaci�n y configuraci�n de Slack
- Investigaci�n espacio WEB y soluci�n de problemas
- Reunion 17-10-2018
- Reunion 15-10-2018
- Moderaci�n ponencia Rafael Fresno

Tiempo total en estas evidencias: 6h y 10 minutos