Evidencias:
- Comunicaci�nes, revisi�n de las tareas y realizaci�n de evidencias
- Duplicado de la WEB y copia de la base de datos Mysql.
- Realizaci�n de modificaciones a la p�gina WEB.
- Preparaci�n y participaci�n en el torneo Bitnami.

Tiempo total en estas evidencias: 7h y 50 minutos

