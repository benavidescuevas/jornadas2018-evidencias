En este paquete se encuentran 2 evidencias: la referente a la colocaci�n de los
primeros carteles de publicidad de Innosoft Days dentro de la ETSII y a la 
colocaci�n de los carteles de publicidad actualizados tanto dentro como fuera 
de la ETSII.

Horas invertidas en Colocaci�n de los Primeros Carteles: 2 horas
Horas invertidas en Colocaci�n de Carteles Actualizados: 6 horas y 45 minutos
