En este paquete se encuentran las evidencias referentes a la asistencia
de 2 de las reuniones del grupo de comunicaci�n: la del d�a 10/10/2018
y la del d�a 15/10/2018.

Horas invertidas en Reuni�n 10/10/2018: 1 hora
Horas invertidas en Reuni�n 15/10/2018: 1 hora