Horas de trabajo en el paquete de evidencias n�1:

*5 horas vendiendo papeletas
*3 horas de reuni�n con el Comit� de Comunicaci�n
*1 hora borrando contenido del servidor

Tiempo total: 9 horas