Horas de trabajo en el paquete de evidencias n�2:

*2 horas de moderadora en el taller de Blockchain
*1 hora y 20 minutos corrigiendo errores ortogr�ficos y sint�cticos en la p�gina de Ponentes
*2 horas publicando noticias en InnoSoft Days
*2 horas y 30 minutos reajustando el CSS para mostrar los logotipos de los patrocinadores de manera m�s agardable y colocando patrocinadores
*4 horas con mockups para los formularios de la p�gina web

Tiempo total: 11 horas y 50 minutos