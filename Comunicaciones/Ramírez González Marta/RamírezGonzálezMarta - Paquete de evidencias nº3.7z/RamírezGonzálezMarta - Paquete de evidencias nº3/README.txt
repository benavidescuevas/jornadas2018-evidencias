Horas de trabajo en el paquete de evidencias n�3:

*6 horas de asistencia a las Jornadas EGC
*5 horas y 30 minutos creando, arreglando y revisando el programa de la web
*2 horas investigando el problema de indexaci�n de p�ginas indicado por Yoast SEO
*2 horas actualizando las inscripciones a actividades de las Jornadas
*20 minutos para crear y enviar las �ltimas entradas de Black Mirror que se solicitaron a �ltima hora

Tiempo total: 15 horas y 50 minutos