En este paquete se incluyen las evidencias sobre:
	-La documentaci�n de las actas de las reuniones.
	-Realizaci�n de resumenes de las reuniones para informar a todo el comit�.
	-Preparaci�n de las evidencias de todos los miembros del comit� que han participado en las jornadas.

El total de horas invertidas son 7.58 horas.