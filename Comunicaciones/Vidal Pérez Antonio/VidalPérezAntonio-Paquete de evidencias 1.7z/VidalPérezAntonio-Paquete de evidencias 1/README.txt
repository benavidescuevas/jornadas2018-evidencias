En este paquete de evidencias se han incluido todas las reuniones asistidas, ya sea dentro del comit� de comunicaciones, 
entre otros comit�s o las reuniones generales realizadas por presidencia.

Las horas totales invertidas son 14.46 horas.