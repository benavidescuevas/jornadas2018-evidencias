En este paquete de evidencias se incluyen todos los documentos relacionados con las reuniones del comit� a la 
que he asistido. 

En total se han realizado 3 reuniones. A continuaci�n se detallan las horas imputadas en las reuniones:

 - UtrillaMartinJuanCarlos-1-Reunion 20181015 Comunicaci�n: 1.5 horas
 - UtrillaMartinJuanCarlos-2-Reunion 20181018 Comunicaci�n: 2.5 horas
 - UtrillaMartinJuanCarlos-3-Reunion 20181026 Finanzas:     1   hora
                                                           ------------
                                                            5   horas