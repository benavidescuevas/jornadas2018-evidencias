En este paquete de evidencias se incluyen todos las actividades relacionadas con la b�squeda de patrocinadores
y la redacci�n del documento de presupuestos de las copister�as.

A continuaci�n se detallan las horas imputadas de cada una:

 - Reuni�n para b�squeda de patrocinadores ------------------------------------------------------ 1    hora
 - Conversaciones con posibles patrocinadores en el evento SecAdmin y a GFI Inform�tica --------- 1    hora
 - Correos de patrocinios enviados a Openwebinars, WorkInCompany y atSistemas ------------------- 0.50 horas
 - Redacci�n del documentos de presupuestos para copister�as ------------------------------------ 1    horas
 - Correcciones del documentos de presupuestos -------------------------------------------------- 0.50 horas 
                                                                                                 ------------
                                                                                                  4  horas