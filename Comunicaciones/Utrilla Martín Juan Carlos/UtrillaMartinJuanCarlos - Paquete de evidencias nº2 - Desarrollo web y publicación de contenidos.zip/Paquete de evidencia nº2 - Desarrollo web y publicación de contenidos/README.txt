En este paquete de evidencias se incluyen todos las actividades relacionadas con el desarrollo de la web
basada en wordpress y la publicaci�n del contenido.

A continuaci�n se detallan las horas imputadas de cada una:

 - Modificaciones del pie de p�gina, banner lateral y contenido de la p�gina principal ---------- 1.5 horas
 - Maquetaci�n, correcciones de las ponencias y subida de los backups --------------------------- 7   horas
 - Modificaciones varias en la web -------------------------------------------------------------- 0.5   hora
 - Correcciones del CSS en el pie de p�gina y en el widget de la zona de patrocinadores --------- 1   hora
 - A�adidos ponentes, mejorada la visibilidad de los ponjentes y actualizaci�n de plugins de WP - 1.5 horas
 - A�adida secci�n de colaboradores y a�adidos los colaboradores de �am �am y Wuolah ------------ 0.5 horas
 - Actualizadas fotos de David Barranco y Jos� Fuentes y corregida informaci�n de Sngular ------- 0.5 horas
 - A�adida informaci�n en web sobre la app del evento y creaci�n del c�digo QR de descarga ------ 0.5 horas
 - Correcci�n de URL de patrocinador, a�adido patrocinador, correcci�n de autores de las        
   publicaciones, actualizado el cartel, corregida informaci�n y mejora en la redacci�n de 
   y estilo de los art�culos publicados en web, las categor�as de los art�culos, a�adidos ------- 3   horas
   tags de art�culos publicados y publicaciones del material necesario de los talleres en 
   la secci�n de ponentes
                                                                                                ------------
                                                                                                 16   horas