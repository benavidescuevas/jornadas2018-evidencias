En este paquete se incluyen 4 evidencias, correspondientes a las tareas de descripci�n de los eventos en la app que necesit� 2h para
llevarla a cabo, compilaci�n de la app y despliegue en Play Store que necesit� 4h, mostrar publicidad de InnoSoft en los televisores
y la web de la escuela, invirtiendo 1,5h y a�adiendo un bot�n en la app para poder reservar los eventos, necesitando 1,5h. En total
para ello necesit� 9h.