En este paquete se incluyen 3 evidencias, correspondientes a las tareas de propuesta de logos y papeletas, en las que invert� 2h,
dise�o de la pantalla de inicio de la aplicaci�n Android, en las que invert� 3h y dise�o de la vista de patrocinadores, que necesit� 
3,5h, siendo en total 8,5h las invertidas para realizar las evidencias a�adidas.