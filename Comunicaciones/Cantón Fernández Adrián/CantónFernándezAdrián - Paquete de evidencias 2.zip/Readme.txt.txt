En este paquete se incluyen 3 evidencias, correspondientes a las tareas de implementaci�n de la agenda de la aplicaci�n, en las que 
invert� 4h, dise�o de la vista de patrocinadores, que necesit� 1,5h y carga de datos de la agenda en la app que invert� 3,5h,
siendo en total 9h las invertidas para realizar las evidencias a�adidas.