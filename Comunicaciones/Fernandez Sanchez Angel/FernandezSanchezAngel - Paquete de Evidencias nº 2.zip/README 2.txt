En este paquete estan las evidencias:

3 reuniones del comite de comuniciones del grupo 2, las fechas de estas reunionen son el 10/10/2018, 15/10/2018 y 31/10/2018. 
Cada reunion duro una hora por la tanto las reuniones duraron 3 HORAS en total. 