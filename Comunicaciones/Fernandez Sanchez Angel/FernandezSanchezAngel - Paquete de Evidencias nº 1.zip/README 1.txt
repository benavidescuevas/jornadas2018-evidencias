Aqui se presentan las siguientes evidencias:

Los presupuestos de las copisterias, que duro 2 HORAS y 30 MINUTOS.
 
Colgar los carteles por la ETSII que duro 2 HORAS.

Actualizar los carteles viejos y ademas colgar los nuevos carteles por el resto del campus y comercios alrededor de reina mercedes, duro 6 HORAS y 45 MINUTOS.