En este paquete estan las evidencias:

Venda de papeletas, un total de 20 que tuvo una duracion de 3 HORAS. 
