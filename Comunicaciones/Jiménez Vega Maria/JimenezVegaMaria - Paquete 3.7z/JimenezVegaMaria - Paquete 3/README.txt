En este paquete3 he a�adido las evidencias correspondientes al trabajo realizado en redes sociales durante de las jornadas.
Dicho trabajo constaba de publicar en las redes sociales las distintas actividades que se llevaban a cabo durante las jornadads, adem�s 
durante las ponencias tambi�n se publicaban.
Adem�s de durante las ponencias, se publiqu� post informativos de los pr�ximos d�as, hacer retwteet, publicar historias de instagram, contestar a los mensajes...
Tambi�n he a�adido a este paquete un informe sobre el impacto de las redes sociales.

Evidencia 10: 8 horas
Evidencia 11: 2 horas
Evidencia 12: 2 horas y 20 minutos

Total hora PAQUETE 3: 12 horas y 20 minutos