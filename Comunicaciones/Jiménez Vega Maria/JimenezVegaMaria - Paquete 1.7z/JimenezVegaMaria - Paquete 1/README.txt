En esta paquete de evidencias1 he a�adido las reuniones a las que he asistido del Comit� de Comunicaci�n.
Han sido un total de 3 reuniones.

Evidencia 1: 1 hora
Evidencia 2: 1 horas y 30 minutos
Evidencia 3: 30 minutos

Total PAQUETE 1: 2 horas