Horas Totales: 9 horas y 50 minutos

Evidencias:
-Posts publicados el d�a 9 de noviembre
-Publicaciones de los d�as 10, 11 y 12 de noviembre.