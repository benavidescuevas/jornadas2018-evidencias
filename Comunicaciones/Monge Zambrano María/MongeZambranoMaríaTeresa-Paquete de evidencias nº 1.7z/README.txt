Horas totales: 8 horas

Las evidencias incluidas han sido las siguientes:
- Reuni�n con integrantes del comit� de comunicaci�n (10-10-2018)
- Reuni�n con integrantes del comit� de comunicaci�n (15-10-2018)
- Trabajo realizado entre los d�as 16 y 29 de Octubre
- Publicaciones entre los d�as 1 y 8 de Noviembre