Este paquete se corresponde a mi trabajo previo y posterior a las jornadas en relacion a la organizacion y gestion de las mismas el cual
me llevo un tiempo total: 19h 12minutos