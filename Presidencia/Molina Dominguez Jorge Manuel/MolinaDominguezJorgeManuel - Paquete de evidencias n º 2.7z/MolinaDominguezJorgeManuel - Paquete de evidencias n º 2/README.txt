Este paquete se corresponde a mi trabajo durante las jornadas y el excel de evidencia a entregar al profesor lo cual
me llevo un tiempo total: 16h 27minutos