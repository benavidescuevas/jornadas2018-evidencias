En este paquete he reunido las reuniones a las que asist� antes de la ejecuci�n de las jornadas. Consta de 7 reuniones:

- Coordinaci�n 19 de octubre (1h)
- Coordinaci�n 26 de octubre (1h20m)
- Coordinaci�n 2 de noviembre (1h40m)
- Coordinaci�n 7 de noviembre (1h18m)
- Presidencia 17 de octubre (1h)
- Presidencia 25 de octubre (50m)
- Taller evidencias 25 de octubre (1h30m)

En total suman 8 horas y 38 minutos.