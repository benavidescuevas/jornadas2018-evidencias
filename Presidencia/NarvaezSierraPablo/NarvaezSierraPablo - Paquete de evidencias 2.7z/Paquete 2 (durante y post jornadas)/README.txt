En este paquete he reunido las reuniones y otros trabajos que realic� durante la ejecuci�n de las jornadas. Consta de 2 reuniones y 2 trabajos, y una evidencia
extra en la que se expone el trabajo de supervisi�n y apoyo realizado:

- Coordinaci�n 23 de noviembre (1h45m)
- Coordinaci�n 30 de noviembre (1h30m)
- Moderaci�n 12 de noviembre (50m)
- Entrevistas Xataka y CSN (1h)
- Supervisi�n y trabajo (12h)

En total suman 5 horas y 5 minutos, junto a las 12 horas de presencia en las jornadas, son 17 horas y 5 minutos.