En este paquete encontramos tanto el trabajo realizado durante la semana de las jornadas
como peque�as tareas que por un motivo u otro nadie mas ha podido hacer.
Horas totales 16 horas y 45 min.