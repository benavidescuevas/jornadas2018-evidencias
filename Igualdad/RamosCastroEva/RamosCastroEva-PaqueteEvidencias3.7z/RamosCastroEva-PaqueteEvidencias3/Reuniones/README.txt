En este paquete se detalla las distintas reuniones de comit� a las que he asistido. 
Horas trabajo: 3.25