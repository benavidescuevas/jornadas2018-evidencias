En este paquete se detalla las distintas actividades llevadas a cabo para realizar los mu�ecos.
-Dibujar mu�ecos
-Recortar mu�ecos
-Repartici�n mu�ecos
 
Horas trabajo: 5.34