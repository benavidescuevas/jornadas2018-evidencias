En este paquete se detalla las distintas actividades llevadas a cabo para realizar los 
carteles de Mujeres. 
-B�squeda de lugares para carteles
-B�squeda informaci�n mujeres
-Presupuestos
-Documentos logistica y finanzas
-Realizaci�n Carteles
Horas trabajo: 8