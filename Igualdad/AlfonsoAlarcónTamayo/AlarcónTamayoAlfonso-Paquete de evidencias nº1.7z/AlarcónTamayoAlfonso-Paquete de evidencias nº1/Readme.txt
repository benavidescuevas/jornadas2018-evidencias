En este primer paquete de evidencias he decidido añadir todas las reuniones de organización tanto de mi comité como de la coordinación de las jornadas
	Reuniones de igualdad
	Reuniones de secretaria
	Reuniones de organización general de las jornadas
	
Número total de horas: 11.52 horas