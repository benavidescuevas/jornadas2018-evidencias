En este paquete he añadido todo lo referente a la creación de documentación (Actas) o útiles (Drive ,excels ,doodle...)que se ha ido necesitando tanto para mi comité como para los demás

Número total de horas: 11.01 horas