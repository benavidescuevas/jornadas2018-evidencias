En este paquetes de evidencias se exponen las evidencias relacionadas
 con la preparaci�n e impartici�n de taller infantil impartido el d�a 15 de noviembre.


Tiempo total: 5 horas 44 minutos