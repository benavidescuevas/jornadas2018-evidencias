Este paquete de evidencias incluye todas las actas de reuni�n con el comit� de igualdad as� como
 una actividad en la que particip� (Gymkana)

Tiempo total: 9 horas