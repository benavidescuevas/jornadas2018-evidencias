En este paquete se incluyen las evidencias de las actividades relacionadas exclusivamente con el Comit� de igualdad, tales como las reuniones o el Kahoot.

- Horas totales: 11 horas y 15 minutos.