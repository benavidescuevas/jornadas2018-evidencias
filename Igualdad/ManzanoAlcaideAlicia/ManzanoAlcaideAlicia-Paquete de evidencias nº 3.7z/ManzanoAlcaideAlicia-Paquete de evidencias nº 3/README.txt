p-Crear taller -> 01h 30min
-Previa preparaci�n del taller -> 04h 30min
-Dar el taller -> 03h

Total de horas:9h