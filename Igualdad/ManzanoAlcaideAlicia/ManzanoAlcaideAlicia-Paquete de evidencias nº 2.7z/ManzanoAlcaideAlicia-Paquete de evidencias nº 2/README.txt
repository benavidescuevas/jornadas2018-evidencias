-Creaci�n de minitrabajos -> 45min
-Comunicaci�n con empresas -> 02h
-Documentos para igualdad -> 30min
-Proyecto de los mu�ecos -> 01h 15min
-Reuniones de Coordinadores -> 07h 43min
-Asociaci�n -> 01h 30min


Total de horas: 13h 43min