Se ha realizado la promoci�n de las jornadas, junto con a la entrega de mu�ecos, para ser rellenados durante la promoci�n, y ser expuestos con el prop�sito de hacer un mural que represente la cantidad de distribuci�n de alumnos por g�nero.
En mi caso, he visitado las clases de Ingenier�a del Software: 1�Grupo 4, 1� Grupo 5, 2� Grupo 3.
Se han pedido los corchos m�viles, se han seleccionado las localizaciones de los carteles y se han colgado los carteles impresos.

Tiempo: 1hora 30min