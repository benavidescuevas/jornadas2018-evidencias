Se ha creado un documento de gu�a que sirva para la organizaci�n interna del comit� de igualdad para las jornadas del 2019, con indicaciones sobre la gesti�n actual, las mejoras a la actualizaci�n, pros y contras de las jornadas realizadas y un apartado de lecciones aprendidas.

Tiempo: 2horas 30min