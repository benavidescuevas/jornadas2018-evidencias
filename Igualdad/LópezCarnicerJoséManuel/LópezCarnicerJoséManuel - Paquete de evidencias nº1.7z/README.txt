En este paquete se inclueyen 4 evidencias para diferenciar claramente los 4 procesos principales en los que se ha desarrollado la creaci�n de la asociaci�n.
Las 4 evidencias se dividen en:
1. Recopilaci�n de informaci�n sobre la creaci�n de una asociaci�n. 
2. Recopilaci�n de informaci�n sobre asociaciones universitarias.
3. Creaci�n de la documentaci�n necesaria para crear una asociaci�n en la Junta de Andaluc�a.
4. Entrega de la documentaci�n pertinente para fundar la asociaci�n.

Tiempo: 5horas 55min
