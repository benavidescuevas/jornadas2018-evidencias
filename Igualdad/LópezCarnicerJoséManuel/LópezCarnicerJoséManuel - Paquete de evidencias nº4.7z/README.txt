De los 5 d�as de reuniones, he asistido a 4, siendo el que falta, una cancelaci�n de la reuni�n que se produjo de �ltima hora.
Las reuniones han servido para saber el progreso realizado por parte de los distintos trabajos repartidos internamente al comit�.
Tambi�n se han usado para la toma de decisiones, para anunciar las decisiones tomadas desde las reuniones de coordinaci�n, 
y para gestionar al personal de los distintos trabajos, ya sea reduciendo o aumentando su carga de trabajo en funci�n del tiempo
y cantidad de tareas a realizar.

Tiempo: 5horas 40min
	