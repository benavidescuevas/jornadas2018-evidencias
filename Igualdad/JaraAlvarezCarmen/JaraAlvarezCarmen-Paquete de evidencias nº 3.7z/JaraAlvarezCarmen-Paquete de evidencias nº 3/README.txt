README

explicaci�n evidencias:
Desplazamiento a copister�a e impresi�n de 8 Carteles.

numero total de horas:
2,8