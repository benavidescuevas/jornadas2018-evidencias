README

explicaci�n evidencias:
Reuniones comit� igualdad y de coordinadores

numero total de horas:
16,45 horas