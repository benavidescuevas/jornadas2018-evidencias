README

explicaci�n evidencias:
Preparaci�n plantillas, recortes y visita a clases para personalizaci�n de mu�equito con g�nero.

numero total de horas:
2,9